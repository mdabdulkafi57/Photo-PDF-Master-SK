package com.photopdfmaster.sk;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
