import { CropRect, FilterPreset, PhotoEditSettings, PhotoItem } from '../types';

export const DEFAULT_CROP: CropRect = { x: 0, y: 0, width: 1, height: 1 };

export const DEFAULT_EDIT_SETTINGS: PhotoEditSettings = {
  rotation: 0,
  flipH: false,
  flipV: false,
  crop: { ...DEFAULT_CROP },
  filter: 'original',
  brightness: 0,
  contrast: 0,
};

export function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = (err) => reject(err);
    img.src = src;
  });
}

export function readFileAsDataUrl(file: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject(new Error('Failed to read file as data URL'));
      }
    };
    reader.onerror = () => reject(reader.error || new Error('File read error'));
    reader.readAsDataURL(file);
  });
}

function clampByte(v: number): number {
  return v < 0 ? 0 : v > 255 ? 255 : v;
}

/**
 * Applies pixel-level filter + brightness + contrast directly to Canvas ImageData.
 * Works identically across all desktop and Android WebView browsers.
 */
export function applyPixelEffects(
  imageData: ImageData,
  filter: FilterPreset,
  brightness: number,
  contrast: number
): ImageData {
  if (filter === 'original' && brightness === 0 && contrast === 0) {
    return imageData;
  }

  const data = imageData.data;

  // Combine user brightness/contrast with filter presets
  let bOffset = brightness * 1.8; // -72 to +72
  let cFactor = (259 * (contrast * 1.8 + 255)) / (255 * (259 - contrast * 1.8));
  let saturation = 1;
  let warmBoost = 0;

  if (filter === 'document') {
    bOffset += 14;
    const docC = 38;
    cFactor *= (259 * (docC + 255)) / (255 * (259 - docC));
    saturation = 1.15;
  } else if (filter === 'vivid') {
    bOffset += 4;
    const vivC = 20;
    cFactor *= (259 * (vivC + 255)) / (255 * (259 - vivC));
    saturation = 1.38;
    warmBoost = 6;
  } else if (filter === 'grayscale') {
    saturation = 0;
  } else if (filter === 'bw') {
    saturation = 0;
    bOffset += 12;
    const bwC = 95;
    cFactor *= (259 * (bwC + 255)) / (255 * (259 - bwC));
  }

  for (let i = 0; i < data.length; i += 4) {
    let r = data[i];
    let g = data[i + 1];
    let b = data[i + 2];

    // Brightness & Contrast
    r = cFactor * (r + bOffset - 128) + 128;
    g = cFactor * (g + bOffset - 128) + 128;
    b = cFactor * (b + bOffset - 128) + 128;

    // Saturation / Grayscale / B&W
    if (saturation !== 1) {
      const lum = 0.299 * r + 0.587 * g + 0.114 * b;
      if (filter === 'bw') {
        // Soft-knee crisp document binarization
        const bwVal = lum > 142 ? 255 : lum < 92 ? 0 : (lum - 92) * (255 / 50);
        r = bwVal;
        g = bwVal;
        b = bwVal;
      } else {
        r = lum + saturation * (r - lum);
        g = lum + saturation * (g - lum);
        b = lum + saturation * (b - lum);
      }
    }

    if (warmBoost !== 0) {
      r += warmBoost;
      b -= warmBoost * 0.5;
    }

    data[i] = clampByte(r);
    data[i + 1] = clampByte(g);
    data[i + 2] = clampByte(b);
  }

  return imageData;
}

/**
 * Renders the rotated & flipped image onto a canvas (no crop/filter yet)
 * so the interactive crop stage always operates in visual screen orientation.
 */
export async function renderOrientedCanvas(
  sourceDataUrl: string,
  rotation: 0 | 90 | 180 | 270,
  flipH: boolean,
  flipV: boolean,
  maxDimension = 1400
): Promise<{ canvas: HTMLCanvasElement; width: number; height: number }> {
  const img = await loadImage(sourceDataUrl);
  const srcW = img.naturalWidth || img.width;
  const srcH = img.naturalHeight || img.height;

  const scale = Math.min(1, maxDimension / Math.max(srcW, srcH));
  const drawW = Math.max(1, Math.round(srcW * scale));
  const drawH = Math.max(1, Math.round(srcH * scale));

  const isRotatedSideways = rotation === 90 || rotation === 270;
  const outW = isRotatedSideways ? drawH : drawW;
  const outH = isRotatedSideways ? drawW : drawH;

  const canvas = document.createElement('canvas');
  canvas.width = outW;
  canvas.height = outH;

  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas 2D context unavailable');

  ctx.save();
  ctx.translate(outW / 2, outH / 2);
  ctx.rotate((rotation * Math.PI) / 180);
  ctx.scale(flipH ? -1 : 1, flipV ? -1 : 1);
  ctx.drawImage(img, -drawW / 2, -drawH / 2, drawW, drawH);
  ctx.restore();

  return { canvas, width: outW, height: outH };
}

/**
 * Renders a photo with full rotation, flip, crop, and pixel filter applied.
 */
export async function renderEditedPhoto(
  sourceDataUrl: string,
  edit: PhotoEditSettings,
  maxDimension = 2200,
  jpegQuality = 0.9
): Promise<{ dataUrl: string; width: number; height: number }> {
  const oriented = await renderOrientedCanvas(
    sourceDataUrl,
    edit.rotation,
    edit.flipH,
    edit.flipV,
    maxDimension
  );

  const cropX = Math.max(0, Math.min(1, edit.crop.x));
  const cropY = Math.max(0, Math.min(1, edit.crop.y));
  const cropW = Math.max(0.02, Math.min(1 - cropX, edit.crop.width));
  const cropH = Math.max(0.02, Math.min(1 - cropY, edit.crop.height));

  const sx = Math.round(cropX * oriented.width);
  const sy = Math.round(cropY * oriented.height);
  const sw = Math.max(1, Math.round(cropW * oriented.width));
  const sh = Math.max(1, Math.round(cropH * oriented.height));

  const outCanvas = document.createElement('canvas');
  outCanvas.width = sw;
  outCanvas.height = sh;

  const outCtx = outCanvas.getContext('2d');
  if (!outCtx) throw new Error('Canvas 2D context unavailable');

  outCtx.drawImage(oriented.canvas, sx, sy, sw, sh, 0, 0, sw, sh);

  if (edit.filter !== 'original' || edit.brightness !== 0 || edit.contrast !== 0) {
    const imgData = outCtx.getImageData(0, 0, sw, sh);
    applyPixelEffects(imgData, edit.filter, edit.brightness, edit.contrast);
    outCtx.putImageData(imgData, 0, 0);
  }

  return {
    dataUrl: outCanvas.toDataURL('image/jpeg', jpegQuality),
    width: sw,
    height: sh,
  };
}

/**
 * Generates miniature filter swatch thumbnails for the photo editor.
 */
export async function generateFilterSwatches(
  sourceDataUrl: string,
  edit: PhotoEditSettings
): Promise<Record<FilterPreset, string>> {
  const oriented = await renderOrientedCanvas(
    sourceDataUrl,
    edit.rotation,
    edit.flipH,
    edit.flipV,
    140
  );

  const presets: FilterPreset[] = ['original', 'document', 'grayscale', 'bw', 'vivid'];
  const result = {} as Record<FilterPreset, string>;

  const sx = Math.round(edit.crop.x * oriented.width);
  const sy = Math.round(edit.crop.y * oriented.height);
  const sw = Math.max(1, Math.round(edit.crop.width * oriented.width));
  const sh = Math.max(1, Math.round(edit.crop.height * oriented.height));

  for (const preset of presets) {
    const c = document.createElement('canvas');
    c.width = sw;
    c.height = sh;
    const ctx = c.getContext('2d');
    if (ctx) {
      ctx.drawImage(oriented.canvas, sx, sy, sw, sh, 0, 0, sw, sh);
      if (preset !== 'original') {
        const imgData = ctx.getImageData(0, 0, sw, sh);
        applyPixelEffects(imgData, preset, 0, 0);
        ctx.putImageData(imgData, 0, 0);
      }
      result[preset] = c.toDataURL('image/jpeg', 0.78);
    }
  }

  return result;
}

export async function createPhotoItemFromDataUrl(
  dataUrl: string,
  name: string
): Promise<PhotoItem> {
  const img = await loadImage(dataUrl);
  const originalWidth = img.naturalWidth || img.width;
  const originalHeight = img.naturalHeight || img.height;

  const edit: PhotoEditSettings = {
    ...DEFAULT_EDIT_SETTINGS,
    crop: { ...DEFAULT_CROP },
  };

  const preview = await renderEditedPhoto(dataUrl, edit, 720, 0.85);

  return {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
    name,
    originalDataUrl: dataUrl,
    originalWidth,
    originalHeight,
    previewDataUrl: preview.dataUrl,
    previewWidth: preview.width,
    previewHeight: preview.height,
    edit,
    addedAt: Date.now(),
  };
}
