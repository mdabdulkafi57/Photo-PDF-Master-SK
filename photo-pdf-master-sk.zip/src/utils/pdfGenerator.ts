import { jsPDF } from 'jspdf';
import { MarginPreset, Orientation, PageSize, PdfOptions, PhotoItem, QualityPreset } from '../types';
import { loadImage, renderEditedPhoto } from './imageProcessing';

const PAGE_DIMENSIONS_MM: Record<PageSize, { width: number; height: number }> = {
  A4: { width: 210, height: 297 },
  A3: { width: 297, height: 420 },
  Letter: { width: 215.9, height: 279.4 },
};

const MARGIN_MM: Record<MarginPreset, number> = {
  none: 0,
  narrow: 8,
  standard: 16,
};

const QUALITY_SETTINGS: Record<QualityPreset, { maxDim: number; jpegQuality: number }> = {
  high: { maxDim: 2400, jpegQuality: 0.92 },
  balanced: { maxDim: 1700, jpegQuality: 0.82 },
  compact: { maxDim: 1200, jpegQuality: 0.68 },
};

export function getPageDimensionsMm(size: PageSize, orientation: Orientation): { width: number; height: number } {
  const base = PAGE_DIMENSIONS_MM[size];
  return orientation === 'portrait'
    ? { width: base.width, height: base.height }
    : { width: base.height, height: base.width };
}

/**
 * Renders a compact sheet preview image showing the photo positioned on the actual PDF paper aspect ratio.
 */
async function renderSheetPreview(
  editedDataUrl: string,
  imgW: number,
  imgH: number,
  pageSize: PageSize,
  orientation: Orientation,
  margin: MarginPreset
): Promise<string> {
  const pageDims = getPageDimensionsMm(pageSize, orientation);
  const ratio = pageDims.width / pageDims.height;

  const canvasW = ratio >= 1 ? 640 : Math.round(640 * ratio);
  const canvasH = ratio >= 1 ? Math.round(640 / ratio) : 640;

  const canvas = document.createElement('canvas');
  canvas.width = canvasW;
  canvas.height = canvasH;

  const ctx = canvas.getContext('2d');
  if (!ctx) return editedDataUrl;

  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, canvasW, canvasH);

  const marginPx = (MARGIN_MM[margin] / pageDims.width) * canvasW;
  const availW = Math.max(10, canvasW - marginPx * 2);
  const availH = Math.max(10, canvasH - marginPx * 2);

  const scale = Math.min(availW / imgW, availH / imgH);
  const drawW = imgW * scale;
  const drawH = imgH * scale;
  const drawX = (canvasW - drawW) / 2;
  const drawY = (canvasH - drawH) / 2;

  const img = await loadImage(editedDataUrl);
  ctx.drawImage(img, drawX, drawY, drawW, drawH);

  return canvas.toDataURL('image/jpeg', 0.82);
}

export interface GeneratedPdfResult {
  blob: Blob;
  pageCount: number;
  sizeBytes: number;
  thumbnailDataUrl: string;
  pagePreviews: string[];
}

export async function generatePdfFromPhotos(
  photos: PhotoItem[],
  options: PdfOptions,
  onProgress?: (current: number, total: number) => void
): Promise<GeneratedPdfResult> {
  if (photos.length === 0) {
    throw new Error('No photos selected');
  }

  const pageDims = getPageDimensionsMm(options.pageSize, options.orientation);
  const marginMm = MARGIN_MM[options.margin];
  const { maxDim, jpegQuality } = QUALITY_SETTINGS[options.quality];

  const doc = new jsPDF({
    orientation: options.orientation,
    unit: 'mm',
    format: options.pageSize.toLowerCase() as 'a4' | 'a3' | 'letter',
    compress: true,
  });

  const pagePreviews: string[] = [];

  for (let i = 0; i < photos.length; i++) {
    onProgress?.(i + 1, photos.length);
    const photo = photos[i];

    const rendered = await renderEditedPhoto(
      photo.originalDataUrl,
      photo.edit,
      maxDim,
      jpegQuality
    );

    if (i > 0) {
      doc.addPage(options.pageSize.toLowerCase() as 'a4' | 'a3' | 'letter', options.orientation);
    }

    const availW = Math.max(10, pageDims.width - marginMm * 2);
    const availH = Math.max(10, pageDims.height - marginMm * 2);
    const fitScale = Math.min(availW / rendered.width, availH / rendered.height);

    const drawW = rendered.width * fitScale;
    const drawH = rendered.height * fitScale;
    const offsetX = (pageDims.width - drawW) / 2;
    const offsetY = (pageDims.height - drawH) / 2;

    doc.addImage(rendered.dataUrl, 'JPEG', offsetX, offsetY, drawW, drawH, undefined, 'FAST');

    const sheetPreview = await renderSheetPreview(
      rendered.dataUrl,
      rendered.width,
      rendered.height,
      options.pageSize,
      options.orientation,
      options.margin
    );
    pagePreviews.push(sheetPreview);
  }

  const blob = doc.output('blob');

  return {
    blob,
    pageCount: photos.length,
    sizeBytes: blob.size,
    thumbnailDataUrl: pagePreviews[0] || '',
    pagePreviews,
  };
}
