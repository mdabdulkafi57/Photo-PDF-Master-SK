import { Capacitor } from '@capacitor/core';
import { Directory, Filesystem } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { SavedPdfRecord } from '../types';

const DB_NAME = 'photo_pdf_master_sk_db';
const DB_VERSION = 1;
const STORE_NAME = 'saved_pdfs';

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
        store.createIndex('createdAt', 'createdAt', { unique: false });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('IndexedDB open failed'));
  });
}

function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const res = reader.result;
      if (typeof res === 'string') {
        const commaIndex = res.indexOf(',');
        resolve(commaIndex >= 0 ? res.slice(commaIndex + 1) : res);
      } else {
        reject(new Error('Failed to convert blob to base64'));
      }
    };
    reader.onerror = () => reject(reader.error || new Error('FileReader error'));
    reader.readAsDataURL(blob);
  });
}

export async function getAllSavedPdfs(): Promise<SavedPdfRecord[]> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const req = store.getAll();
    req.onsuccess = () => {
      const records = (req.result as SavedPdfRecord[]) || [];
      records.sort((a, b) => b.createdAt - a.createdAt);
      resolve(records);
    };
    req.onerror = () => reject(req.error || new Error('Failed to fetch saved PDFs'));
  });
}

export async function savePdfRecord(record: SavedPdfRecord): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const req = store.put(record);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error || new Error('Failed to save PDF'));
  });
}

export async function renamePdfRecord(id: string, newName: string): Promise<SavedPdfRecord | null> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const getReq = store.get(id);
    getReq.onsuccess = () => {
      const record = getReq.result as SavedPdfRecord | undefined;
      if (!record) {
        resolve(null);
        return;
      }
      const updated: SavedPdfRecord = { ...record, name: newName };
      const putReq = store.put(updated);
      putReq.onsuccess = () => resolve(updated);
      putReq.onerror = () => reject(putReq.error || new Error('Failed to rename PDF'));
    };
    getReq.onerror = () => reject(getReq.error || new Error('Failed to find PDF'));
  });
}

export async function deletePdfRecord(id: string): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const req = store.delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error || new Error('Failed to delete PDF'));
  });
}

export async function triggerPdfDownload(record: SavedPdfRecord): Promise<void> {
  const safeName = `${record.name.replace(/\.pdf$/i, '')}.pdf`;

  if (Capacitor.isNativePlatform()) {
    try {
      const base64Data = await blobToBase64(record.blob);
      await Filesystem.writeFile({
        path: `PhotoPDFMasterSK/${safeName}`,
        data: base64Data,
        directory: Directory.Documents,
        recursive: true,
      });
      return;
    } catch {
      // Fallback to cache + share or browser download below if Documents write fails
    }
  }

  const url = URL.createObjectURL(record.blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = safeName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}

export async function sharePdfRecord(
  record: SavedPdfRecord
): Promise<'shared' | 'fallback_downloaded' | 'cancelled'> {
  const safeName = `${record.name.replace(/\.pdf$/i, '')}.pdf`;

  if (Capacitor.isNativePlatform()) {
    try {
      const base64Data = await blobToBase64(record.blob);
      const written = await Filesystem.writeFile({
        path: safeName,
        data: base64Data,
        directory: Directory.Cache,
        recursive: true,
      });
      await Share.share({
        title: safeName,
        url: written.uri,
        dialogTitle: safeName,
      });
      return 'shared';
    } catch (err) {
      if (err instanceof Error && /cancel/i.test(err.message)) {
        return 'cancelled';
      }
    }
  }

  const file = new File([record.blob], safeName, { type: 'application/pdf' });

  if (typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
    const canShareFiles =
      typeof navigator.canShare === 'function' ? navigator.canShare({ files: [file] }) : true;
    if (canShareFiles) {
      try {
        await navigator.share({
          title: safeName,
          files: [file],
        });
        return 'shared';
      } catch (err) {
        if (err instanceof Error && err.name === 'AbortError') {
          return 'cancelled';
        }
      }
    }
  }

  await triggerPdfDownload(record);
  return 'fallback_downloaded';
}
