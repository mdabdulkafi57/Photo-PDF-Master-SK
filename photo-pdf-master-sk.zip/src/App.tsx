import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ArrowDown,
  ArrowUp,
  Camera,
  CheckCircle2,
  Copy,
  FileOutput,
  FileText,
  FolderOpen,
  Globe,
  ImagePlus,
  RectangleHorizontal,
  RectangleVertical,
  Sliders,
  Trash2,
  X,
} from 'lucide-react';
import {
  FilterPreset,
  Language,
  MarginPreset,
  Orientation,
  PageSize,
  PdfOptions,
  PhotoEditSettings,
  PhotoItem,
  QualityPreset,
  SavedPdfRecord,
  ToastMessage,
} from './types';
import { TRANSLATIONS, toLocalizedNumber } from './i18n/translations';
import {
  createPhotoItemFromDataUrl,
  readFileAsDataUrl,
  renderEditedPhoto,
} from './utils/imageProcessing';
import { generatePdfFromPhotos, getPageDimensionsMm } from './utils/pdfGenerator';
import {
  deletePdfRecord,
  getAllSavedPdfs,
  renamePdfRecord,
  savePdfRecord,
  sharePdfRecord,
  triggerPdfDownload,
} from './utils/pdfStorage';
import { CameraModal } from './components/CameraModal';
import { PhotoEditorModal } from './components/PhotoEditorModal';
import { PdfPreviewModal } from './components/PdfPreviewModal';
import { SavedPdfsView } from './components/SavedPdfsView';
import { ConfirmDialog, RenameDialog } from './components/Dialogs';

type ActiveView = 'studio' | 'saved';

function makeDefaultFileName(prefix: string): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  const hh = String(now.getHours()).padStart(2, '0');
  const mm = String(now.getMinutes()).padStart(2, '0');
  return `${prefix}_${y}${m}${d}_${hh}${mm}`;
}

export default function App() {
  const [lang, setLang] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('photo_pdf_master_sk_lang');
      return saved === 'bn' ? 'bn' : 'en';
    } catch {
      return 'en';
    }
  });
  const t = TRANSLATIONS[lang];

  const [activeView, setActiveView] = useState<ActiveView>('studio');
  const [photos, setPhotos] = useState<PhotoItem[]>([]);
  const [savedPdfs, setSavedPdfs] = useState<SavedPdfRecord[]>([]);

  // PDF Configuration
  const [fileName, setFileName] = useState<string>(() => makeDefaultFileName('PhotoPDF_SK'));
  const [pageSize, setPageSize] = useState<PageSize>('A4');
  const [orientation, setOrientation] = useState<Orientation>('portrait');
  const [margin, setMargin] = useState<MarginPreset>('narrow');
  const [quality, setQuality] = useState<QualityPreset>('high');

  // Interactive Modals & States
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [editingPhotoId, setEditingPhotoId] = useState<string | null>(null);
  const [previewPdf, setPreviewPdf] = useState<SavedPdfRecord | null>(null);
  const [renameTarget, setRenameTarget] = useState<SavedPdfRecord | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<SavedPdfRecord | null>(null);
  const [confirmClearOpen, setConfirmClearOpen] = useState(false);

  const [isDraggingOver, setIsDraggingOver] = useState(false);
  const [isConverting, setIsConverting] = useState(false);
  const [convertProgress, setConvertProgress] = useState<{ current: number; total: number } | null>(
    null
  );
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const galleryInputRef = useRef<HTMLInputElement | null>(null);

  const pushToast = useCallback((type: ToastMessage['type'], message: string) => {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    setToasts((prev) => [...prev.slice(-2), { id, type, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((item) => item.id !== id));
    }, 3600);
  }, []);

  // Load saved PDFs from IndexedDB on mount
  useEffect(() => {
    let active = true;
    getAllSavedPdfs()
      .then((items) => {
        if (active) setSavedPdfs(items);
      })
      .catch(() => {
        // IndexedDB may be unavailable in restricted contexts
      });
    return () => {
      active = false;
    };
  }, []);

  // Persist language choice & update document lang attribute
  useEffect(() => {
    document.documentElement.lang = lang;
    try {
      localStorage.setItem('photo_pdf_master_sk_lang', lang);
    } catch {
      // ignore
    }
  }, [lang]);

  const toggleLanguage = () => {
    setLang((prev) => (prev === 'en' ? 'bn' : 'en'));
  };

  // Add photos from FileList or File[]
  const addImageFiles = async (fileList: FileList | File[]) => {
    const files = Array.from(fileList);
    if (files.length === 0) return;

    const added: PhotoItem[] = [];
    let failedCount = 0;

    for (const file of files) {
      if (!file.type.startsWith('image/')) {
        failedCount++;
        continue;
      }
      try {
        const dataUrl = await readFileAsDataUrl(file);
        const item = await createPhotoItemFromDataUrl(dataUrl, file.name);
        added.push(item);
      } catch {
        failedCount++;
      }
    }

    if (added.length > 0) {
      setPhotos((prev) => [...prev, ...added]);
      setActiveView('studio');
      pushToast('success', t.photosAdded(added.length));
    }
    if (failedCount > 0) {
      pushToast('error', t.errorLoadingImages);
    }
  };

  const handleGalleryInputChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      await addImageFiles(e.target.files);
      e.target.value = '';
    }
  };

  const handleCameraConfirm = async (dataUrls: string[]) => {
    setIsCameraOpen(false);
    const created: PhotoItem[] = [];
    for (let i = 0; i < dataUrls.length; i++) {
      try {
        const item = await createPhotoItemFromDataUrl(
          dataUrls[i],
          `Camera_${Date.now()}_${i + 1}.jpg`
        );
        created.push(item);
      } catch {
        // skip
      }
    }
    if (created.length > 0) {
      setPhotos((prev) => [...prev, ...created]);
      setActiveView('studio');
      pushToast('success', t.photosAdded(created.length));
    }
  };

  const handleSavePhotoEdit = async (photoId: string, newEdit: PhotoEditSettings) => {
    const target = photos.find((p) => p.id === photoId);
    if (!target) return;

    const updatedPreview = await renderEditedPhoto(target.originalDataUrl, newEdit, 720, 0.85);
    setPhotos((prev) =>
      prev.map((p) =>
        p.id === photoId
          ? {
              ...p,
              edit: newEdit,
              previewDataUrl: updatedPreview.dataUrl,
              previewWidth: updatedPreview.width,
              previewHeight: updatedPreview.height,
            }
          : p
      )
    );
  };

  const handleApplyFilterToAll = async (
    filter: FilterPreset,
    brightness: number,
    contrast: number
  ) => {
    const updatedPhotos = await Promise.all(
      photos.map(async (p) => {
        const nextEdit: PhotoEditSettings = {
          ...p.edit,
          filter,
          brightness,
          contrast,
        };
        const preview = await renderEditedPhoto(p.originalDataUrl, nextEdit, 720, 0.85);
        return {
          ...p,
          edit: nextEdit,
          previewDataUrl: preview.dataUrl,
          previewWidth: preview.width,
          previewHeight: preview.height,
        };
      })
    );
    setPhotos(updatedPhotos);
    pushToast('info', t.appliedFilterToAll);
  };

  const movePhoto = (index: number, direction: -1 | 1) => {
    const targetIndex = index + direction;
    if (targetIndex < 0 || targetIndex >= photos.length) return;
    setPhotos((prev) => {
      const next = [...prev];
      const [moved] = next.splice(index, 1);
      next.splice(targetIndex, 0, moved);
      return next;
    });
  };

  const duplicatePhoto = (index: number) => {
    const source = photos[index];
    if (!source) return;
    const copy: PhotoItem = {
      ...source,
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
      edit: { ...source.edit, crop: { ...source.edit.crop } },
      addedAt: Date.now(),
    };
    setPhotos((prev) => {
      const next = [...prev];
      next.splice(index + 1, 0, copy);
      return next;
    });
  };

  const removePhoto = (photoId: string) => {
    setPhotos((prev) => prev.filter((p) => p.id !== photoId));
  };

  const handleConvertToPdf = async () => {
    if (photos.length === 0 || isConverting) return;

    const cleanName =
      fileName.trim().replace(/\.pdf$/i, '') || makeDefaultFileName(t.defaultFilePrefix);

    const options: PdfOptions = {
      fileName: cleanName,
      pageSize,
      orientation,
      margin,
      quality,
    };

    setIsConverting(true);
    setConvertProgress({ current: 0, total: photos.length });

    try {
      const result = await generatePdfFromPhotos(photos, options, (current, total) => {
        setConvertProgress({ current, total });
      });

      const newRecord: SavedPdfRecord = {
        id: `pdf-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        name: cleanName,
        createdAt: Date.now(),
        pageCount: result.pageCount,
        pageSize,
        orientation,
        margin,
        sizeBytes: result.sizeBytes,
        thumbnailDataUrl: result.thumbnailDataUrl,
        pagePreviews: result.pagePreviews,
        blob: result.blob,
      };

      await savePdfRecord(newRecord);
      setSavedPdfs((prev) => [newRecord, ...prev]);
      setFileName(makeDefaultFileName(t.defaultFilePrefix));
      setPreviewPdf(newRecord);
      pushToast('success', t.pdfCreatedSuccess(cleanName));
    } catch {
      pushToast('error', t.errorCreatingPdf);
    } finally {
      setIsConverting(false);
      setConvertProgress(null);
    }
  };

  const handleDownloadPdf = async (record: SavedPdfRecord) => {
    await triggerPdfDownload(record);
    pushToast('success', t.pdfDownloadedSuccess);
  };

  const handleSharePdf = async (record: SavedPdfRecord) => {
    const outcome = await sharePdfRecord(record);
    if (outcome === 'shared') {
      pushToast('success', t.pdfSharedSuccess);
    } else if (outcome === 'fallback_downloaded') {
      pushToast('info', t.shareFallbackDownload);
    }
  };

  const handleConfirmRename = async (newName: string) => {
    if (!renameTarget) return;
    const updated = await renamePdfRecord(renameTarget.id, newName);
    if (updated) {
      setSavedPdfs((prev) => prev.map((item) => (item.id === updated.id ? updated : item)));
      if (previewPdf?.id === updated.id) {
        setPreviewPdf(updated);
      }
      pushToast('success', t.pdfRenamedSuccess);
    }
    setRenameTarget(null);
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    await deletePdfRecord(deleteTarget.id);
    setSavedPdfs((prev) => prev.filter((item) => item.id !== deleteTarget.id));
    if (previewPdf?.id === deleteTarget.id) {
      setPreviewPdf(null);
    }
    setDeleteTarget(null);
    pushToast('info', t.pdfDeletedSuccess);
  };

  // Drag & Drop handlers on Studio
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    if (!isDraggingOver) setIsDraggingOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.currentTarget.contains(e.relatedTarget as Node)) return;
    setIsDraggingOver(false);
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      await addImageFiles(e.dataTransfer.files);
    }
  };

  const editingPhotoIndex = editingPhotoId
    ? photos.findIndex((p) => p.id === editingPhotoId)
    : -1;
  const editingPhoto = editingPhotoIndex >= 0 ? photos[editingPhotoIndex] : null;

  const livePageDims = getPageDimensionsMm(pageSize, orientation);
  const livePageAspectRatio = `${livePageDims.width} / ${livePageDims.height}`;
  const sheetPaddingClass =
    margin === 'none' ? 'p-0' : margin === 'narrow' ? 'p-2.5' : 'p-5';

  return (
    <div className="min-h-screen flex flex-col bg-[#F4F5F7] text-slate-900">
      {/* Hidden Gallery Multi-File Input */}
      <input
        ref={galleryInputRef}
        type="file"
        accept="image/*"
        multiple
        onChange={handleGalleryInputChange}
        className="hidden"
      />

      {/* Top Navigation Bar (Strict 3-Zone Contract) */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-12 md:h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Brand Wordmark */}
          <button
            type="button"
            onClick={() => setActiveView('studio')}
            className="flex items-center gap-2.5 text-left whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D92D20] rounded-lg"
          >
            <svg
              width="28"
              height="28"
              viewBox="0 0 28 28"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="shrink-0"
              aria-hidden="true"
            >
              <rect width="28" height="28" rx="7" fill="#D92D20" />
              <path
                d="M9 7.5H15.5L19.5 11.5V20.5C19.5 21.0523 19.0523 21.5 18.5 21.5H9C8.44772 21.5 8 21.0523 8 20.5V8.5C8 7.94772 8.44772 7.5 9 7.5Z"
                fill="white"
              />
              <path d="M15.5 7.5V11.5H19.5" fill="#FDE8E6" />
              <path
                d="M10.75 15.75L12.75 13.75L14.75 15.75L16.75 14L17.5 17.5H10.5L10.75 15.75Z"
                fill="#D92D20"
              />
            </svg>
            <span className="text-base sm:text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0">
              {t.appName}
            </span>
          </button>

          {/* Zone 2: Desktop Single-Line Navigation Links */}
          <nav className="hidden md:flex items-center gap-8 text-sm font-medium">
            <button
              type="button"
              onClick={() => setActiveView('studio')}
              className={`py-1 border-b-2 transition-colors whitespace-nowrap shrink-0 ${
                activeView === 'studio'
                  ? 'border-[#D92D20] text-slate-900 font-semibold'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              {t.navStudio}
            </button>
            <button
              type="button"
              onClick={() => setActiveView('saved')}
              className={`py-1 border-b-2 transition-colors whitespace-nowrap shrink-0 tabular-nums ${
                activeView === 'saved'
                  ? 'border-[#D92D20] text-slate-900 font-semibold'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              {t.navSavedPdfs} ({toLocalizedNumber(savedPdfs.length, lang)})
            </button>
          </nav>

          {/* Zone 3: Single Primary Language Action */}
          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={toggleLanguage}
              className="min-h-[40px] px-3.5 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-xs sm:text-sm font-semibold text-slate-800 inline-flex items-center gap-2 transition-colors whitespace-nowrap shrink-0"
              aria-label="Switch language"
            >
              <Globe className="w-4 h-4 text-[#D92D20]" />
              <span>{t.languageSwitchLabel}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-24 md:pb-12">
        {activeView === 'studio' ? (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start">
            {/* Left Workspace: Photo Sources & Live Page Sheet Grid */}
            <div
              className="lg:col-span-8 space-y-5"
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              {/* Workspace Heading & Quick Source Bar */}
              <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
                <div>
                  <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 text-balance">
                    {t.studioTitle}
                  </h1>
                  <p className="mt-1 text-sm text-slate-600">{t.studioSubtitle}</p>
                </div>

                {photos.length > 0 && (
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-xs font-medium text-slate-500 tabular-nums mr-1">
                      {t.pagesCount(photos.length)}
                    </span>
                    <button
                      type="button"
                      onClick={() => setConfirmClearOpen(true)}
                      className="min-h-[40px] px-3 rounded-xl border border-slate-200 bg-white hover:bg-red-50 hover:border-red-200 hover:text-red-700 text-xs font-medium text-slate-700 transition-colors whitespace-nowrap"
                    >
                      {t.clearAll}
                    </button>
                  </div>
                )}
              </div>

              {/* Action Buttons Bar */}
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => galleryInputRef.current?.click()}
                  className="min-h-[48px] px-4 py-3 rounded-2xl bg-white border border-slate-200 hover:border-slate-300 hover:bg-slate-50 text-slate-900 text-sm font-semibold flex items-center justify-center gap-2.5 shadow-2xs transition-colors whitespace-nowrap"
                >
                  <ImagePlus className="w-5 h-5 text-[#D92D20] shrink-0" />
                  <span className="truncate">{t.addFromGallery}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsCameraOpen(true)}
                  className="min-h-[48px] px-4 py-3 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold flex items-center justify-center gap-2.5 shadow-2xs transition-colors whitespace-nowrap"
                >
                  <Camera className="w-5 h-5 shrink-0" />
                  <span className="truncate">{t.takePhoto}</span>
                </button>
              </div>

              {/* Empty Drop Zone OR Photo Pages Grid */}
              {photos.length === 0 ? (
                <div
                  className={`rounded-3xl border-2 border-dashed p-8 sm:p-14 text-center transition-colors ${
                    isDraggingOver
                      ? 'border-[#D92D20] bg-[#D92D20]/5'
                      : 'border-slate-300 bg-white'
                  }`}
                >
                  <div className="w-16 h-20 mx-auto rounded-lg border border-slate-200 bg-slate-50 flex flex-col items-center justify-center gap-1.5 shadow-2xs">
                    <ImagePlus className="w-6 h-6 text-[#D92D20]" />
                    <span className="text-[10px] font-mono-nums text-slate-400">PDF</span>
                  </div>
                  <h2 className="mt-5 text-lg font-semibold text-slate-900 text-balance">
                    {t.dropHintTitle}
                  </h2>
                  <p className="mt-1.5 text-sm text-slate-600 max-w-md mx-auto leading-relaxed">
                    {t.dropHintSubtitle}
                  </p>
                  <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
                    <button
                      type="button"
                      onClick={() => galleryInputRef.current?.click()}
                      className="min-h-[44px] px-5 py-2.5 rounded-xl bg-[#D92D20] hover:bg-[#B42318] text-white text-sm font-semibold inline-flex items-center gap-2 transition-colors whitespace-nowrap"
                    >
                      <ImagePlus className="w-4 h-4" />
                      <span>{t.addFromGallery}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsCameraOpen(true)}
                      className="min-h-[44px] px-5 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-800 text-sm font-semibold inline-flex items-center gap-2 transition-colors whitespace-nowrap"
                    >
                      <Camera className="w-4 h-4" />
                      <span>{t.takePhoto}</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div
                  className={`grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 rounded-2xl transition-colors ${
                    isDraggingOver ? 'ring-2 ring-[#D92D20] ring-offset-4 ring-offset-[#F4F5F7]' : ''
                  }`}
                >
                  {photos.map((photo, index) => (
                    <article
                      key={photo.id}
                      className="bg-white rounded-2xl border border-slate-200 p-3 flex flex-col gap-3"
                    >
                      {/* Top Bar: Page Number + Filter Name + Remove */}
                      <div className="flex items-center justify-between gap-2">
                        <div className="min-w-0 flex items-center gap-2 text-xs text-slate-500 tabular-nums">
                          <span className="font-mono-nums font-semibold text-slate-900">
                            {toLocalizedNumber(String(index + 1).padStart(2, '0'), lang)}
                          </span>
                          {photo.edit.filter !== 'original' && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span className="truncate">{t.filters[photo.edit.filter]}</span>
                            </>
                          )}
                        </div>

                        <button
                          type="button"
                          onClick={() => removePhoto(photo.id)}
                          aria-label={`${t.removePhoto} ${index + 1}`}
                          title={t.removePhoto}
                          className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Live Page Aspect Preview */}
                      <button
                        type="button"
                        onClick={() => setEditingPhotoId(photo.id)}
                        className="w-full bg-slate-100 rounded-xl p-3 flex items-center justify-center group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D92D20]"
                        aria-label={`${t.editPhoto} ${t.pageLabel} ${index + 1}`}
                      >
                        <div
                          className={`bg-white shadow-sm border border-slate-200 overflow-hidden flex items-center justify-center w-full max-h-56 transition-transform duration-150 group-hover:scale-[1.01] ${sheetPaddingClass}`}
                          style={{ aspectRatio: livePageAspectRatio }}
                        >
                          <img
                            src={photo.previewDataUrl}
                            alt={photo.name}
                            className="max-w-full max-h-full w-auto h-auto object-contain"
                          />
                        </div>
                      </button>

                      {/* Card Controls */}
                      <div className="flex items-center justify-between gap-1.5 pt-1 border-t border-slate-100">
                        <button
                          type="button"
                          onClick={() => setEditingPhotoId(photo.id)}
                          className="min-h-[40px] flex-1 px-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-800 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap"
                        >
                          <Sliders className="w-3.5 h-3.5 text-[#D92D20]" />
                          <span>{t.editPhoto}</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => movePhoto(index, -1)}
                          disabled={index === 0}
                          title={t.moveUp}
                          aria-label={t.moveUp}
                          className="min-h-[40px] min-w-[40px] rounded-xl bg-slate-50 hover:bg-slate-100 disabled:opacity-35 text-slate-700 flex items-center justify-center transition-colors"
                        >
                          <ArrowUp className="w-4 h-4" />
                        </button>

                        <button
                          type="button"
                          onClick={() => movePhoto(index, 1)}
                          disabled={index === photos.length - 1}
                          title={t.moveDown}
                          aria-label={t.moveDown}
                          className="min-h-[40px] min-w-[40px] rounded-xl bg-slate-50 hover:bg-slate-100 disabled:opacity-35 text-slate-700 flex items-center justify-center transition-colors"
                        >
                          <ArrowDown className="w-4 h-4" />
                        </button>

                        <button
                          type="button"
                          onClick={() => duplicatePhoto(index)}
                          title={t.duplicatePhoto}
                          aria-label={t.duplicatePhoto}
                          className="min-h-[40px] min-w-[40px] rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-700 flex items-center justify-center transition-colors"
                        >
                          <Copy className="w-4 h-4" />
                        </button>
                      </div>
                    </article>
                  ))}
                </div>
              )}
            </div>

            {/* Right Sidebar: PDF Layout Settings & Convert CTA */}
            <aside className="lg:col-span-4 lg:sticky lg:top-22 bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 space-y-5">
              <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-100">
                <h2 className="text-base font-semibold text-slate-900">
                  {t.pdfSettingsTitle}
                </h2>
                <span className="text-xs text-slate-500 font-mono-nums">
                  {pageSize} · {orientation === 'portrait' ? t.portrait : t.landscape}
                </span>
              </div>

              {/* File Name */}
              <div className="space-y-1.5">
                <label
                  htmlFor="pdf-filename-input"
                  className="block text-xs font-semibold text-slate-700"
                >
                  {t.fileNameLabel}
                </label>
                <div className="relative flex items-center">
                  <input
                    id="pdf-filename-input"
                    type="text"
                    value={fileName}
                    onChange={(e) => setFileName(e.target.value)}
                    placeholder={t.fileNamePlaceholder}
                    className="w-full min-h-[44px] pl-3.5 pr-12 py-2 rounded-xl border border-slate-200 bg-slate-50/60 focus:bg-white text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#D92D20]/25 focus:border-[#D92D20]"
                  />
                  <span className="absolute right-3.5 text-xs font-mono-nums text-slate-400 pointer-events-none">
                    .pdf
                  </span>
                </div>
              </div>

              {/* Page Size Selector: A4, A3, Letter */}
              <div className="space-y-2">
                <span className="block text-xs font-semibold text-slate-700">
                  {t.pageSizeLabel}
                </span>
                <div className="grid grid-cols-3 gap-2">
                  {(['A4', 'A3', 'Letter'] as PageSize[]).map((size) => {
                    const active = pageSize === size;
                    return (
                      <button
                        key={size}
                        type="button"
                        onClick={() => setPageSize(size)}
                        className={`min-h-[56px] px-2.5 py-2 rounded-xl border text-center transition-colors flex flex-col items-center justify-center ${
                          active
                            ? 'border-[#D92D20] bg-[#D92D20]/5 text-slate-900'
                            : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                        }`}
                      >
                        <span className="text-sm font-semibold">{t.pageSizes[size].label}</span>
                        <span className="text-[11px] text-slate-500 font-mono-nums mt-0.5">
                          {t.pageSizes[size].dimensions}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Orientation Selector: Portrait / Landscape */}
              <div className="space-y-2">
                <span className="block text-xs font-semibold text-slate-700">
                  {t.orientationLabel}
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setOrientation('portrait')}
                    className={`min-h-[44px] px-3 py-2 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap ${
                      orientation === 'portrait'
                        ? 'border-[#D92D20] bg-[#D92D20]/5 text-slate-900'
                        : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <RectangleVertical className="w-4 h-4 shrink-0" />
                    <span>{t.portrait}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setOrientation('landscape')}
                    className={`min-h-[44px] px-3 py-2 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap ${
                      orientation === 'landscape'
                        ? 'border-[#D92D20] bg-[#D92D20]/5 text-slate-900'
                        : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <RectangleHorizontal className="w-4 h-4 shrink-0" />
                    <span>{t.landscape}</span>
                  </button>
                </div>
              </div>

              {/* Margin Selector */}
              <div className="space-y-2">
                <span className="block text-xs font-semibold text-slate-700">
                  {t.marginLabel}
                </span>
                <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-100 rounded-xl">
                  {(['none', 'narrow', 'standard'] as MarginPreset[]).map((m) => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setMargin(m)}
                      className={`min-h-[40px] px-2 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                        margin === m
                          ? 'bg-white text-slate-900 shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      {t.margins[m]}
                    </button>
                  ))}
                </div>
              </div>

              {/* Quality Selector */}
              <div className="space-y-2">
                <span className="block text-xs font-semibold text-slate-700">
                  {t.qualityLabel}
                </span>
                <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-100 rounded-xl">
                  {(['high', 'balanced', 'compact'] as QualityPreset[]).map((q) => (
                    <button
                      key={q}
                      type="button"
                      onClick={() => setQuality(q)}
                      className={`min-h-[40px] px-2 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                        quality === q
                          ? 'bg-white text-slate-900 shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      {t.qualities[q]}
                    </button>
                  ))}
                </div>
              </div>

              {/* Primary Export Action */}
              <div className="pt-2 space-y-2">
                <button
                  type="button"
                  onClick={handleConvertToPdf}
                  disabled={photos.length === 0 || isConverting}
                  className="w-full min-h-[48px] px-5 py-3 rounded-xl bg-[#D92D20] hover:bg-[#B42318] disabled:bg-slate-200 disabled:text-slate-400 text-white text-sm font-semibold flex items-center justify-center gap-2 shadow-sm transition-colors"
                >
                  {isConverting ? (
                    <>
                      <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      <span>
                        {convertProgress
                          ? t.convertingProgress(convertProgress.current, convertProgress.total)
                          : t.convertingPdf}
                      </span>
                    </>
                  ) : (
                    <>
                      <FileOutput className="w-4 h-4 shrink-0" />
                      <span>{t.convertToPdf}</span>
                    </>
                  )}
                </button>
                {photos.length === 0 && (
                  <p className="text-xs text-slate-500 text-center">{t.addPhotosFirstHint}</p>
                )}
              </div>
            </aside>
          </div>
        ) : (
          <SavedPdfsView
            pdfs={savedPdfs}
            lang={lang}
            onGoToStudio={() => setActiveView('studio')}
            onPreview={(record) => setPreviewPdf(record)}
            onDownload={handleDownloadPdf}
            onShare={handleSharePdf}
            onRequestRename={(record) => setRenameTarget(record)}
            onRequestDelete={(record) => setDeleteTarget(record)}
          />
        )}
      </main>

      {/* Mobile Bottom Thumb-Zone Navigation Bar (<= 15% total sticky cap) */}
      <nav
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 pb-safe"
        aria-label="Mobile Navigation"
      >
        <div className="grid grid-cols-3 items-center h-14">
          <button
            type="button"
            onClick={() => setActiveView('studio')}
            className={`h-full flex flex-col items-center justify-center gap-0.5 transition-colors ${
              activeView === 'studio' ? 'text-[#D92D20]' : 'text-slate-500'
            }`}
          >
            <FileText className="w-5 h-5" />
            <span className="text-[11px] font-medium tracking-tight">{t.navStudio}</span>
          </button>

          <button
            type="button"
            onClick={() => setIsCameraOpen(true)}
            className="h-full flex flex-col items-center justify-center gap-0.5 text-slate-900"
          >
            <span className="w-9 h-9 rounded-full bg-[#D92D20] text-white flex items-center justify-center shadow-xs">
              <Camera className="w-4 h-4" />
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveView('saved')}
            className={`h-full flex flex-col items-center justify-center gap-0.5 transition-colors ${
              activeView === 'saved' ? 'text-[#D92D20]' : 'text-slate-500'
            }`}
          >
            <FolderOpen className="w-5 h-5" />
            <span className="text-[11px] font-medium tracking-tight tabular-nums">
              {t.navSavedPdfs} ({toLocalizedNumber(savedPdfs.length, lang)})
            </span>
          </button>
        </div>
      </nav>

      {/* Modals */}
      <CameraModal
        isOpen={isCameraOpen}
        lang={lang}
        onClose={() => setIsCameraOpen(false)}
        onConfirmPhotos={handleCameraConfirm}
      />

      <PhotoEditorModal
        photo={editingPhoto}
        pageNumber={editingPhotoIndex + 1}
        totalPhotos={photos.length}
        lang={lang}
        onClose={() => setEditingPhotoId(null)}
        onSave={handleSavePhotoEdit}
        onApplyFilterToAll={handleApplyFilterToAll}
      />

      <PdfPreviewModal
        record={previewPdf}
        lang={lang}
        onClose={() => setPreviewPdf(null)}
        onDownload={handleDownloadPdf}
        onShare={handleSharePdf}
        onRequestRename={(record) => setRenameTarget(record)}
        onRequestDelete={(record) => setDeleteTarget(record)}
      />

      <RenameDialog
        isOpen={Boolean(renameTarget)}
        initialName={renameTarget?.name ?? ''}
        lang={lang}
        onClose={() => setRenameTarget(null)}
        onConfirm={handleConfirmRename}
      />

      <ConfirmDialog
        isOpen={Boolean(deleteTarget)}
        title={t.deleteTitle}
        body={deleteTarget ? t.deleteConfirmBody(deleteTarget.name) : ''}
        confirmLabel={t.confirmDelete}
        cancelLabel={t.cancel}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleConfirmDelete}
      />

      <ConfirmDialog
        isOpen={confirmClearOpen}
        title={t.confirmClearAllTitle}
        body={t.confirmClearAllBody}
        confirmLabel={t.clearAll}
        cancelLabel={t.cancel}
        onClose={() => setConfirmClearOpen(false)}
        onConfirm={() => {
          setPhotos([]);
          setConfirmClearOpen(false);
        }}
      />

      {/* Toast Notifications */}
      <div className="fixed bottom-18 md:bottom-6 right-4 z-[70] flex flex-col gap-2 max-w-sm w-[calc(100%-2rem)] sm:w-auto pointer-events-none">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            role="status"
            className="pointer-events-auto bg-slate-900 text-white rounded-xl px-4 py-3 shadow-lg flex items-center justify-between gap-3 text-xs sm:text-sm"
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <CheckCircle2
                className={`w-4 h-4 shrink-0 ${
                  toast.type === 'error' ? 'text-red-400' : 'text-emerald-400'
                }`}
              />
              <span className="leading-snug">{toast.message}</span>
            </div>
            <button
              type="button"
              onClick={() => setToasts((prev) => prev.filter((item) => item.id !== toast.id))}
              className="text-slate-400 hover:text-white shrink-0 p-1"
              aria-label={t.close}
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
