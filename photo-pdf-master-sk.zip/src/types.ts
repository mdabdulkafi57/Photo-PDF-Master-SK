export type Language = 'en' | 'bn';

export type PageSize = 'A4' | 'A3' | 'Letter';

export type Orientation = 'portrait' | 'landscape';

export type MarginPreset = 'none' | 'narrow' | 'standard';

export type QualityPreset = 'high' | 'balanced' | 'compact';

export type FilterPreset = 'original' | 'document' | 'grayscale' | 'bw' | 'vivid';

export type CropAspectPreset = 'free' | 'a4' | 'square' | '4:3' | '3:2';

export interface CropRect {
  /** Normalized 0..1 coordinates relative to the rotated & flipped image */
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface PhotoEditSettings {
  rotation: 0 | 90 | 180 | 270;
  flipH: boolean;
  flipV: boolean;
  crop: CropRect;
  filter: FilterPreset;
  brightness: number; // -40 to +40
  contrast: number; // -40 to +40
}

export interface PhotoItem {
  id: string;
  name: string;
  originalDataUrl: string;
  originalWidth: number;
  originalHeight: number;
  previewDataUrl: string;
  previewWidth: number;
  previewHeight: number;
  edit: PhotoEditSettings;
  addedAt: number;
}

export interface PdfOptions {
  fileName: string;
  pageSize: PageSize;
  orientation: Orientation;
  margin: MarginPreset;
  quality: QualityPreset;
}

export interface SavedPdfRecord {
  id: string;
  name: string;
  createdAt: number;
  pageCount: number;
  pageSize: PageSize;
  orientation: Orientation;
  margin: MarginPreset;
  sizeBytes: number;
  thumbnailDataUrl: string;
  pagePreviews: string[];
  blob: Blob;
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}
