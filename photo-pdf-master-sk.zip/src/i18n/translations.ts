import { FilterPreset, Language, MarginPreset, PageSize, QualityPreset } from '../types';

export interface TranslationStrings {
  appName: string;
  navStudio: string;
  navSavedPdfs: string;
  navCamera: string;
  languageSwitchLabel: string;

  // Studio header & upload actions
  studioTitle: string;
  studioSubtitle: string;
  addFromGallery: string;
  takePhoto: string;
  dropHintTitle: string;
  dropHintSubtitle: string;
  clearAll: string;
  confirmClearAllTitle: string;
  confirmClearAllBody: string;

  // Photo list & card actions
  pageLabel: string;
  pagesCount: (n: number) => string;
  editPhoto: string;
  moveUp: string;
  moveDown: string;
  duplicatePhoto: string;
  removePhoto: string;
  applyFilterToAll: string;
  appliedFilterToAll: string;

  // PDF settings panel
  pdfSettingsTitle: string;
  fileNameLabel: string;
  fileNamePlaceholder: string;
  defaultFilePrefix: string;
  pageSizeLabel: string;
  orientationLabel: string;
  portrait: string;
  landscape: string;
  marginLabel: string;
  qualityLabel: string;
  convertToPdf: string;
  convertingPdf: string;
  convertingProgress: (current: number, total: number) => string;
  addPhotosFirstHint: string;

  // Page sizes, margins, quality
  pageSizes: Record<PageSize, { label: string; dimensions: string }>;
  margins: Record<MarginPreset, string>;
  qualities: Record<QualityPreset, string>;

  // Photo Editor Modal
  editorTitle: string;
  tabCrop: string;
  tabRotate: string;
  tabFilter: string;
  aspectFree: string;
  aspectA4: string;
  aspectSquare: string;
  rotateLeft: string;
  rotateRight: string;
  flipHorizontal: string;
  flipVertical: string;
  resetCrop: string;
  resetAll: string;
  brightnessLabel: string;
  contrastLabel: string;
  applyChanges: string;
  cancel: string;
  filters: Record<FilterPreset, string>;

  // Camera Modal
  cameraTitle: string;
  cameraPermissionDenied: string;
  cameraUnavailable: string;
  cameraFallbackAction: string;
  switchCamera: string;
  capturePhoto: string;
  retakeLast: string;
  addCapturedPhotos: (n: number) => string;
  cameraGuideHint: string;
  capturedCount: (n: number) => string;

  // Saved PDFs view
  savedPdfsTitle: string;
  savedPdfsSubtitle: string;
  searchPlaceholder: string;
  sortNewest: string;
  sortOldest: string;
  sortName: string;
  sortSize: string;
  noPdfsTitle: string;
  noPdfsSubtitle: string;
  noMatchingPdfs: string;
  goToStudio: string;
  previewPdf: string;
  downloadPdf: string;
  sharePdf: string;
  renamePdf: string;
  deletePdf: string;

  // Rename & Delete Modals
  renameTitle: string;
  renamePlaceholder: string;
  saveName: string;
  deleteTitle: string;
  deleteConfirmBody: (name: string) => string;
  confirmDelete: string;

  // Preview Modal
  previewTitle: string;
  pageOfTotal: (page: number, total: number) => string;
  nativeViewerToggle: string;
  pageImagesToggle: string;
  close: string;

  // Toasts & feedback
  pdfCreatedSuccess: (name: string) => string;
  pdfRenamedSuccess: string;
  pdfDeletedSuccess: string;
  pdfDownloadedSuccess: string;
  pdfSharedSuccess: string;
  shareFallbackDownload: string;
  photosAdded: (n: number) => string;
  errorLoadingImages: string;
  errorCreatingPdf: string;
}

export const TRANSLATIONS: Record<Language, TranslationStrings> = {
  en: {
    appName: 'Photo PDF Master SK',
    navStudio: 'Create PDF',
    navSavedPdfs: 'Saved PDFs',
    navCamera: 'Camera',
    languageSwitchLabel: 'বাংলা',

    studioTitle: 'Photo to PDF Studio',
    studioSubtitle: 'Select gallery photos or capture scans, edit pages, and export crisp PDFs.',
    addFromGallery: 'Select Photos',
    takePhoto: 'Use Camera',
    dropHintTitle: 'Add photos to start building your PDF',
    dropHintSubtitle: 'Choose multiple images from your gallery, drag and drop files here, or snap pages with your camera.',
    clearAll: 'Clear All',
    confirmClearAllTitle: 'Clear all photos?',
    confirmClearAllBody: 'This will remove all selected photos from the current workspace. Your saved PDFs will not be affected.',

    pageLabel: 'Page',
    pagesCount: (n) => (n === 1 ? '1 page' : `${n} pages`),
    editPhoto: 'Edit',
    moveUp: 'Move Up',
    moveDown: 'Move Down',
    duplicatePhoto: 'Duplicate',
    removePhoto: 'Remove',
    applyFilterToAll: 'Apply filter to all',
    appliedFilterToAll: 'Applied current filter to all pages',

    pdfSettingsTitle: 'PDF Layout & Export',
    fileNameLabel: 'File Name',
    fileNamePlaceholder: 'Enter PDF file name',
    defaultFilePrefix: 'PhotoPDF_SK',
    pageSizeLabel: 'Page Size',
    orientationLabel: 'Orientation',
    portrait: 'Portrait',
    landscape: 'Landscape',
    marginLabel: 'Page Margin',
    qualityLabel: 'Quality',
    convertToPdf: 'Convert to PDF',
    convertingPdf: 'Creating PDF...',
    convertingProgress: (current, total) => `Processing page ${current} of ${total}...`,
    addPhotosFirstHint: 'Add at least one photo to create a PDF.',

    pageSizes: {
      A4: { label: 'A4', dimensions: '210 × 297 mm' },
      A3: { label: 'A3', dimensions: '297 × 420 mm' },
      Letter: { label: 'Letter', dimensions: '215.9 × 279.4 mm' },
    },
    margins: {
      none: 'Full Bleed',
      narrow: 'Narrow',
      standard: 'Standard',
    },
    qualities: {
      high: 'High',
      balanced: 'Balanced',
      compact: 'Compact',
    },

    editorTitle: 'Edit Photo',
    tabCrop: 'Crop',
    tabRotate: 'Rotate',
    tabFilter: 'Filters',
    aspectFree: 'Free',
    aspectA4: 'A4',
    aspectSquare: '1:1',
    rotateLeft: 'Rotate Left',
    rotateRight: 'Rotate Right',
    flipHorizontal: 'Flip Horizontal',
    flipVertical: 'Flip Vertical',
    resetCrop: 'Reset Crop',
    resetAll: 'Reset All',
    brightnessLabel: 'Brightness',
    contrastLabel: 'Contrast',
    applyChanges: 'Apply Changes',
    cancel: 'Cancel',
    filters: {
      original: 'Original',
      document: 'Document Crisp',
      grayscale: 'Grayscale',
      bw: 'B&W Scan',
      vivid: 'Vivid',
    },

    cameraTitle: 'Camera Scanner',
    cameraPermissionDenied: 'Camera permission was denied. Allow camera access in your browser settings or upload a photo directly.',
    cameraUnavailable: 'Live camera preview is unavailable on this device. Use the button below to take or choose a photo.',
    cameraFallbackAction: 'Take / Choose Photo',
    switchCamera: 'Flip Camera',
    capturePhoto: 'Capture',
    retakeLast: 'Discard Last',
    addCapturedPhotos: (n) => (n === 1 ? 'Add 1 Photo' : `Add ${n} Photos`),
    cameraGuideHint: 'Align your document or photo inside the frame',
    capturedCount: (n) => `${n} captured`,

    savedPdfsTitle: 'Saved PDFs',
    savedPdfsSubtitle: 'View, rename, download, or share your created PDF documents.',
    searchPlaceholder: 'Search PDFs by name...',
    sortNewest: 'Newest first',
    sortOldest: 'Oldest first',
    sortName: 'Name (A–Z)',
    sortSize: 'Largest first',
    noPdfsTitle: 'No saved PDFs yet',
    noPdfsSubtitle: 'Convert your photos in the Create PDF studio and your saved documents will appear here.',
    noMatchingPdfs: 'No PDFs match your search.',
    goToStudio: 'Create First PDF',
    previewPdf: 'Preview',
    downloadPdf: 'Download',
    sharePdf: 'Share',
    renamePdf: 'Rename',
    deletePdf: 'Delete',

    renameTitle: 'Rename PDF',
    renamePlaceholder: 'Enter new PDF name',
    saveName: 'Save Name',
    deleteTitle: 'Delete PDF?',
    deleteConfirmBody: (name) => `Are you sure you want to permanently delete "${name}.pdf"?`,
    confirmDelete: 'Delete PDF',

    previewTitle: 'PDF Preview',
    pageOfTotal: (page, total) => `Page ${page} of ${total}`,
    nativeViewerToggle: 'Document Embed',
    pageImagesToggle: 'Page View',
    close: 'Close',

    pdfCreatedSuccess: (name) => `"${name}.pdf" saved to your PDFs list.`,
    pdfRenamedSuccess: 'PDF renamed successfully.',
    pdfDeletedSuccess: 'PDF deleted.',
    pdfDownloadedSuccess: 'PDF download started.',
    pdfSharedSuccess: 'PDF shared.',
    shareFallbackDownload: 'Direct sharing is unavailable in this browser; downloaded PDF instead.',
    photosAdded: (n) => (n === 1 ? '1 photo added.' : `${n} photos added.`),
    errorLoadingImages: 'Some selected files could not be read as images.',
    errorCreatingPdf: 'Could not generate the PDF. Please try again.',
  },
  bn: {
    appName: 'Photo PDF Master SK',
    navStudio: 'পিডিএফ তৈরি',
    navSavedPdfs: 'সংরক্ষিত পিডিএফ',
    navCamera: 'ক্যামেরা',
    languageSwitchLabel: 'English',

    studioTitle: 'ছবি থেকে পিডিএফ স্টুডিও',
    studioSubtitle: 'গ্যালারি থেকে ছবি বাছাই করুন বা ক্যামেরায় তুলুন, এডিট করে পরিষ্কার পিডিএফ বানান।',
    addFromGallery: 'ছবি বাছাই করুন',
    takePhoto: 'ক্যামেরা ব্যবহার করুন',
    dropHintTitle: 'পিডিএফ তৈরি শুরু করতে ছবি যোগ করুন',
    dropHintSubtitle: 'গ্যালারি থেকে একসাথে একাধিক ছবি বেছে নিন, এখানে ড্র্যাগ করে ছাড়ুন অথবা ক্যামেরা দিয়ে ছবি তুলুন।',
    clearAll: 'সব মুছুন',
    confirmClearAllTitle: 'সব ছবি সরিয়ে ফেলবেন?',
    confirmClearAllBody: 'এতে বর্তমান কাজের তালিকা থেকে সব ছবি সরে যাবে। আপনার সংরক্ষিত পিডিএফ ফাইলগুলো নিরাপদ থাকবে।',

    pageLabel: 'পৃষ্ঠা',
    pagesCount: (n) => `${toLocalizedNumber(n, 'bn')}টি পৃষ্ঠা`,
    editPhoto: 'এডিট',
    moveUp: 'উপরে নিন',
    moveDown: 'নিচে নিন',
    duplicatePhoto: 'ডুপ্লিকেট',
    removePhoto: 'সরান',
    applyFilterToAll: 'সব পৃষ্ঠায় ফিল্টার দিন',
    appliedFilterToAll: 'বর্তমান ফিল্টারটি সব ছবিতে প্রয়োগ করা হয়েছে',

    pdfSettingsTitle: 'পিডিএফ সেটিংস ও এক্সপোর্ট',
    fileNameLabel: 'ফাইলের নাম',
    fileNamePlaceholder: 'পিডিএফ ফাইলের নাম লিখুন',
    defaultFilePrefix: 'PhotoPDF_SK',
    pageSizeLabel: 'পেজের আকার',
    orientationLabel: 'অরিয়েন্টেশন',
    portrait: 'পোর্ট্রেট (লম্বা)',
    landscape: 'ল্যান্ডস্কেপ (আড়াআড়ি)',
    marginLabel: 'পৃষ্ঠার মার্জিন',
    qualityLabel: 'ছবির মান',
    convertToPdf: 'পিডিএফ তৈরি করুন',
    convertingPdf: 'পিডিএফ তৈরি হচ্ছে...',
    convertingProgress: (current, total) =>
      `${toLocalizedNumber(total, 'bn')}টির মধ্যে ${toLocalizedNumber(current, 'bn')}নং পৃষ্ঠা প্রস্তুত হচ্ছে...`,
    addPhotosFirstHint: 'পিডিএফ তৈরি করতে অন্তত একটি ছবি যোগ করুন।',

    pageSizes: {
      A4: { label: 'A4', dimensions: '২১০ × ২৯৭ মিমি' },
      A3: { label: 'A3', dimensions: '২৯৭ × ৪২০ মিমি' },
      Letter: { label: 'Letter', dimensions: '২১৫.৯ × ২৭৯.৪ মিমি' },
    },
    margins: {
      none: 'মার্জিন ছাড়া',
      narrow: 'ছোট মার্জিন',
      standard: 'স্বাভাবিক',
    },
    qualities: {
      high: 'উচ্চ মান',
      balanced: 'মাঝারি',
      compact: 'কম সাইজ',
    },

    editorTitle: 'ছবি এডিট করুন',
    tabCrop: 'ক্রপ',
    tabRotate: 'ঘোরান',
    tabFilter: 'ফিল্টার',
    aspectFree: 'মুক্ত',
    aspectA4: 'A4',
    aspectSquare: '১:১',
    rotateLeft: 'বামে ঘোরান',
    rotateRight: 'ডানে ঘোরান',
    flipHorizontal: 'উল্টো (আড়াআড়ি)',
    flipVertical: 'উল্টো (উপর-নিচ)',
    resetCrop: 'ক্রপ রিসেট',
    resetAll: 'সব রিসেট',
    brightnessLabel: 'উজ্জ্বলতা',
    contrastLabel: 'কনট্রাস্ট',
    applyChanges: 'পরিবর্তন সেভ করুন',
    cancel: 'বাতিল',
    filters: {
      original: 'আসল',
      document: 'ডকুমেন্ট ক্লিয়ার',
      grayscale: 'গ্রেস্কেল',
      bw: 'সাদাকালো স্ক্যান',
      vivid: 'উজ্জ্বল রঙ',
    },

    cameraTitle: 'ক্যামেরা স্ক্যানার',
    cameraPermissionDenied: 'ক্যামেরা ব্যবহারের অনুমতি পাওয়া যায়নি। ব্রাউজার সেটিংস থেকে অনুমতি দিন অথবা সরাসরি ছবি আপলোড করুন।',
    cameraUnavailable: 'এই ডিভাইসে সরাসরি ক্যামেরা প্রিভিউ চালু করা যায়নি। নিচের বাটন দিয়ে ছবি তুলুন বা বাছাই করুন।',
    cameraFallbackAction: 'ছবি তুলুন / বাছাই করুন',
    switchCamera: 'ক্যামেরা বদলান',
    capturePhoto: 'ছবি তুলুন',
    retakeLast: 'শেষ ছবি বাদ দিন',
    addCapturedPhotos: (n) => `${toLocalizedNumber(n, 'bn')}টি ছবি যোগ করুন`,
    cameraGuideHint: 'ডকুমেন্ট বা ছবি ফ্রেমের ভেতরে সোজা করে ধরুন',
    capturedCount: (n) => `${toLocalizedNumber(n, 'bn')}টি তোলা হয়েছে`,

    savedPdfsTitle: 'সংরক্ষিত পিডিএফ তালিকা',
    savedPdfsSubtitle: 'তৈরি করা পিডিএফ ফাইল দেখুন, নাম পরিবর্তন করুন, ডাউনলোড বা শেয়ার করুন।',
    searchPlaceholder: 'নাম দিয়ে পিডিএফ খুঁজুন...',
    sortNewest: 'নতুনগুলো আগে',
    sortOldest: 'পুরনোগুলো আগে',
    sortName: 'নাম অনুযায়ী (A–Z)',
    sortSize: 'বড় ফাইল আগে',
    noPdfsTitle: 'এখনো কোনো পিডিএফ তৈরি হয়নি',
    noPdfsSubtitle: 'পিডিএফ তৈরি স্টুডিও থেকে ছবি রূপান্তর করলে সেগুলো এখানে সংরক্ষিত থাকবে।',
    noMatchingPdfs: 'খোঁজার সাথে কোনো পিডিএফ মেলেনি।',
    goToStudio: 'প্রথম পিডিএফ তৈরি করুন',
    previewPdf: 'দেখুন',
    downloadPdf: 'ডাউনলোড',
    sharePdf: 'শেয়ার',
    renamePdf: 'নাম বদলান',
    deletePdf: 'মুছুন',

    renameTitle: 'পিডিএফের নাম পরিবর্তন',
    renamePlaceholder: 'নতুন নাম লিখুন',
    saveName: 'নাম সেভ করুন',
    deleteTitle: 'পিডিএফ মুছে ফেলবেন?',
    deleteConfirmBody: (name) => `আপনি কি "${name}.pdf" ফাইলটি স্থায়ীভাবে মুছে ফেলতে চান?`,
    confirmDelete: 'মুছে ফেলুন',

    previewTitle: 'পিডিএফ প্রিভিউ',
    pageOfTotal: (page, total) =>
      `পৃষ্ঠা ${toLocalizedNumber(page, 'bn')} / ${toLocalizedNumber(total, 'bn')}`,
    nativeViewerToggle: 'ডকুমেন্ট ভিউ',
    pageImagesToggle: 'পৃষ্ঠা প্রিভিউ',
    close: 'বন্ধ করুন',

    pdfCreatedSuccess: (name) => `"${name}.pdf" সফলভাবে সংরক্ষিত হয়েছে।`,
    pdfRenamedSuccess: 'পিডিএফের নাম পরিবর্তন হয়েছে।',
    pdfDeletedSuccess: 'পিডিএফ মুছে ফেলা হয়েছে।',
    pdfDownloadedSuccess: 'পিডিএফ ডাউনলোড শুরু হয়েছে।',
    pdfSharedSuccess: 'পিডিএফ শেয়ার করা হয়েছে।',
    shareFallbackDownload: 'এই ব্রাউজারে সরাসরি শেয়ার সাপোর্ট করে না; ফাইলটি ডাউনলোড করা হয়েছে।',
    photosAdded: (n) => `${toLocalizedNumber(n, 'bn')}টি ছবি যোগ করা হয়েছে।`,
    errorLoadingImages: 'কিছু ফাইল ছবি হিসেবে পড়া যায়নি।',
    errorCreatingPdf: 'পিডিএফ তৈরি করতে সমস্যা হয়েছে। আবার চেষ্টা করুন।',
  },
};

const BENGALI_DIGITS = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];

export function toLocalizedNumber(value: number | string, lang: Language): string {
  const str = String(value);
  if (lang !== 'bn') return str;
  return str.replace(/\d/g, (digit) => BENGALI_DIGITS[Number(digit)] ?? digit);
}

export function formatBytes(bytes: number, lang: Language): string {
  if (bytes < 1024) {
    return `${toLocalizedNumber(bytes, lang)} ${lang === 'bn' ? 'বাইট' : 'B'}`;
  }
  const kb = bytes / 1024;
  if (kb < 1024) {
    return `${toLocalizedNumber(kb.toFixed(1), lang)} ${lang === 'bn' ? 'কেবি' : 'KB'}`;
  }
  const mb = kb / 1024;
  return `${toLocalizedNumber(mb.toFixed(2), lang)} ${lang === 'bn' ? 'এমবি' : 'MB'}`;
}

export function formatDateTime(timestamp: number, lang: Language): string {
  try {
    return new Intl.DateTimeFormat(lang === 'bn' ? 'bn-BD' : 'en-US', {
      dateStyle: 'medium',
      timeStyle: 'short',
    }).format(new Date(timestamp));
  } catch {
    return new Date(timestamp).toLocaleString();
  }
}
