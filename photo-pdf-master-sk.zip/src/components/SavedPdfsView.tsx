import React, { useMemo, useState } from 'react';
import {
  Download,
  Edit3,
  Eye,
  FileText,
  Plus,
  Search,
  Share2,
  Trash2,
} from 'lucide-react';
import { Language, SavedPdfRecord } from '../types';
import {
  TRANSLATIONS,
  formatBytes,
  formatDateTime,
} from '../i18n/translations';

interface SavedPdfsViewProps {
  pdfs: SavedPdfRecord[];
  lang: Language;
  onGoToStudio: () => void;
  onPreview: (record: SavedPdfRecord) => void;
  onDownload: (record: SavedPdfRecord) => void;
  onShare: (record: SavedPdfRecord) => void;
  onRequestRename: (record: SavedPdfRecord) => void;
  onRequestDelete: (record: SavedPdfRecord) => void;
}

type SortOption = 'newest' | 'oldest' | 'name' | 'size';

export const SavedPdfsView: React.FC<SavedPdfsViewProps> = ({
  pdfs,
  lang,
  onGoToStudio,
  onPreview,
  onDownload,
  onShare,
  onRequestRename,
  onRequestDelete,
}) => {
  const t = TRANSLATIONS[lang];
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<SortOption>('newest');

  const filteredPdfs = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const list = q
      ? pdfs.filter((item) => item.name.toLowerCase().includes(q))
      : [...pdfs];

    list.sort((a, b) => {
      if (sortBy === 'newest') return b.createdAt - a.createdAt;
      if (sortBy === 'oldest') return a.createdAt - b.createdAt;
      if (sortBy === 'name') return a.name.localeCompare(b.name);
      if (sortBy === 'size') return b.sizeBytes - a.sizeBytes;
      return 0;
    });
    return list;
  }, [pdfs, searchQuery, sortBy]);

  return (
    <section className="space-y-6">
      {/* Header Row */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 text-balance">
            {t.savedPdfsTitle}
          </h1>
          <p className="mt-1 text-sm text-slate-600">{t.savedPdfsSubtitle}</p>
        </div>

        <button
          type="button"
          onClick={onGoToStudio}
          className="min-h-[44px] px-4 py-2.5 rounded-xl bg-[#D92D20] hover:bg-[#B42318] text-white text-sm font-semibold inline-flex items-center justify-center gap-2 transition-colors whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>{t.navStudio}</span>
        </button>
      </div>

      {/* Search & Sort Controls */}
      {pdfs.length > 0 && (
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.searchPlaceholder}
              className="w-full min-h-[44px] pl-10 pr-4 py-2 rounded-xl bg-white border border-slate-200 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#D92D20]/25 focus:border-[#D92D20]"
            />
          </div>

          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as SortOption)}
            aria-label="Sort PDFs"
            className="min-h-[44px] px-3.5 py-2 rounded-xl bg-white border border-slate-200 text-sm font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-[#D92D20]/25 focus:border-[#D92D20]"
          >
            <option value="newest">{t.sortNewest}</option>
            <option value="oldest">{t.sortOldest}</option>
            <option value="name">{t.sortName}</option>
            <option value="size">{t.sortSize}</option>
          </select>
        </div>
      )}

      {/* Empty States */}
      {pdfs.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-8 sm:p-14 text-center max-w-2xl mx-auto">
          <div className="w-14 h-14 rounded-2xl bg-slate-100 text-slate-700 flex items-center justify-center mx-auto">
            <FileText className="w-7 h-7" />
          </div>
          <h2 className="mt-4 text-lg font-semibold text-slate-900">{t.noPdfsTitle}</h2>
          <p className="mt-1.5 text-sm text-slate-600 max-w-md mx-auto leading-relaxed">
            {t.noPdfsSubtitle}
          </p>
          <button
            type="button"
            onClick={onGoToStudio}
            className="mt-6 min-h-[44px] px-5 py-2.5 rounded-xl bg-[#D92D20] hover:bg-[#B42318] text-white text-sm font-semibold inline-flex items-center gap-2 transition-colors whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            <span>{t.goToStudio}</span>
          </button>
        </div>
      ) : filteredPdfs.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-10 text-center text-sm text-slate-600">
          {t.noMatchingPdfs}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredPdfs.map((record) => {
            const orientationLabel =
              record.orientation === 'portrait' ? t.portrait : t.landscape;

            return (
              <article
                key={record.id}
                className="bg-white rounded-2xl border border-slate-200 p-4 flex flex-col justify-between gap-4 hover:border-slate-300 transition-colors"
              >
                <div
                  onClick={() => onPreview(record)}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      onPreview(record);
                    }
                  }}
                  className="flex items-start gap-3.5 text-left group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D92D20] rounded-xl"
                >
                  {/* Thumbnail Sheet */}
                  <div className="w-16 h-22 rounded-lg border border-slate-200 bg-slate-50 overflow-hidden shrink-0 flex items-center justify-center">
                    {record.thumbnailDataUrl ? (
                      <img
                        src={record.thumbnailDataUrl}
                        alt={record.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <FileText className="w-6 h-6 text-slate-400" />
                    )}
                  </div>

                  {/* Unboxed Metadata */}
                  <div className="min-w-0 flex-1 space-y-1">
                    <h3 className="text-sm font-semibold text-slate-900 group-hover:text-[#D92D20] transition-colors truncate">
                      {record.name}.pdf
                    </h3>
                    <p className="text-xs text-slate-500 tabular-nums">
                      {t.pagesCount(record.pageCount)} · {record.pageSize} · {orientationLabel}
                    </p>
                    <p className="text-xs text-slate-500 tabular-nums">
                      {formatBytes(record.sizeBytes, lang)} · {formatDateTime(record.createdAt, lang)}
                    </p>
                  </div>
                </div>

                {/* Action Row */}
                <div className="pt-3 border-t border-slate-100 grid grid-cols-5 gap-1.5">
                  <button
                    type="button"
                    onClick={() => onPreview(record)}
                    title={t.previewPdf}
                    aria-label={`${t.previewPdf} ${record.name}`}
                    className="min-h-[42px] rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-700 flex items-center justify-center transition-colors"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onShare(record)}
                    title={t.sharePdf}
                    aria-label={`${t.sharePdf} ${record.name}`}
                    className="min-h-[42px] rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-700 flex items-center justify-center transition-colors"
                  >
                    <Share2 className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onDownload(record)}
                    title={t.downloadPdf}
                    aria-label={`${t.downloadPdf} ${record.name}`}
                    className="min-h-[42px] rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-700 flex items-center justify-center transition-colors"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onRequestRename(record)}
                    title={t.renamePdf}
                    aria-label={`${t.renamePdf} ${record.name}`}
                    className="min-h-[42px] rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-700 flex items-center justify-center transition-colors"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onRequestDelete(record)}
                    title={t.deletePdf}
                    aria-label={`${t.deletePdf} ${record.name}`}
                    className="min-h-[42px] rounded-xl bg-red-50/70 hover:bg-red-100 text-red-700 flex items-center justify-center transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </section>
  );
};
