import React, { useEffect, useRef, useState } from 'react';
import {
  Check,
  Crop as CropIcon,
  FlipHorizontal2,
  FlipVertical2,
  RotateCcw,
  RotateCw,
  SlidersHorizontal,
  Sparkles,
  X,
} from 'lucide-react';
import {
  CropAspectPreset,
  CropRect,
  FilterPreset,
  Language,
  PhotoEditSettings,
  PhotoItem,
} from '../types';
import { TRANSLATIONS, toLocalizedNumber } from '../i18n/translations';
import {
  DEFAULT_CROP,
  DEFAULT_EDIT_SETTINGS,
  applyPixelEffects,
  generateFilterSwatches,
  renderOrientedCanvas,
} from '../utils/imageProcessing';

interface PhotoEditorModalProps {
  photo: PhotoItem | null;
  pageNumber: number;
  totalPhotos: number;
  lang: Language;
  onClose: () => void;
  onSave: (photoId: string, newEdit: PhotoEditSettings) => Promise<void>;
  onApplyFilterToAll: (filter: FilterPreset, brightness: number, contrast: number) => Promise<void>;
}

type EditorTab = 'crop' | 'rotate' | 'filter';
type DragHandle = 'move' | 'nw' | 'ne' | 'sw' | 'se' | 'n' | 's' | 'e' | 'w';

const MIN_CROP_SIZE = 0.08;

export const PhotoEditorModal: React.FC<PhotoEditorModalProps> = ({
  photo,
  pageNumber,
  totalPhotos,
  lang,
  onClose,
  onSave,
  onApplyFilterToAll,
}) => {
  const t = TRANSLATIONS[lang];

  const [activeTab, setActiveTab] = useState<EditorTab>('crop');
  const [edit, setEdit] = useState<PhotoEditSettings>({
    ...DEFAULT_EDIT_SETTINGS,
    crop: { ...DEFAULT_CROP },
  });
  const [aspectPreset, setAspectPreset] = useState<CropAspectPreset>('free');
  const [orientedPreviewUrl, setOrientedPreviewUrl] = useState<string>('');
  const [filteredPreviewUrl, setFilteredPreviewUrl] = useState<string>('');
  const [orientedDims, setOrientedDims] = useState<{ width: number; height: number }>({
    width: 1,
    height: 1,
  });
  const [swatches, setSwatches] = useState<Partial<Record<FilterPreset, string>>>({});
  const [isSaving, setIsSaving] = useState(false);
  const [isApplyingAll, setIsApplyingAll] = useState(false);

  const stageRef = useRef<HTMLDivElement | null>(null);
  const dragStateRef = useRef<{
    handle: DragHandle;
    startX: number;
    startY: number;
    startCrop: CropRect;
    stageRect: DOMRect;
  } | null>(null);

  // Initialize from photo when opened
  useEffect(() => {
    if (!photo) return;
    setEdit({
      ...photo.edit,
      crop: { ...photo.edit.crop },
    });
    setActiveTab('crop');
    setAspectPreset('free');
  }, [photo]);

  // Recompute oriented base preview whenever rotation/flip changes
  useEffect(() => {
    if (!photo) return;
    let cancelled = false;

    (async () => {
      const oriented = await renderOrientedCanvas(
        photo.originalDataUrl,
        edit.rotation,
        edit.flipH,
        edit.flipV,
        960
      );
      if (cancelled) return;
      setOrientedDims({ width: oriented.width, height: oriented.height });
      setOrientedPreviewUrl(oriented.canvas.toDataURL('image/jpeg', 0.88));
    })();

    return () => {
      cancelled = true;
    };
  }, [photo, edit.rotation, edit.flipH, edit.flipV]);

  // Recompute filtered stage preview when filter/brightness/contrast or oriented base changes
  useEffect(() => {
    if (!photo || !orientedPreviewUrl) return;
    let cancelled = false;

    (async () => {
      if (edit.filter === 'original' && edit.brightness === 0 && edit.contrast === 0) {
        setFilteredPreviewUrl(orientedPreviewUrl);
        return;
      }
      const oriented = await renderOrientedCanvas(
        photo.originalDataUrl,
        edit.rotation,
        edit.flipH,
        edit.flipV,
        720
      );
      if (cancelled) return;
      const ctx = oriented.canvas.getContext('2d');
      if (ctx) {
        const imgData = ctx.getImageData(0, 0, oriented.width, oriented.height);
        applyPixelEffects(imgData, edit.filter, edit.brightness, edit.contrast);
        ctx.putImageData(imgData, 0, 0);
        setFilteredPreviewUrl(oriented.canvas.toDataURL('image/jpeg', 0.86));
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [photo, orientedPreviewUrl, edit.rotation, edit.flipH, edit.flipV, edit.filter, edit.brightness, edit.contrast]);

  // Generate filter swatches when opening Filter tab or changing orientation/crop
  useEffect(() => {
    if (!photo || activeTab !== 'filter') return;
    let cancelled = false;

    (async () => {
      const map = await generateFilterSwatches(photo.originalDataUrl, edit);
      if (!cancelled) setSwatches(map);
    })();

    return () => {
      cancelled = true;
    };
  }, [photo, activeTab, edit.rotation, edit.flipH, edit.flipV, edit.crop]);

  if (!photo) return null;

  const getTargetAspect = (preset: CropAspectPreset): number | null => {
    const imgRatio = orientedDims.width / Math.max(1, orientedDims.height);
    if (preset === 'free') return null;
    if (preset === 'square') return 1 / imgRatio;
    if (preset === 'a4') return (210 / 297) / imgRatio;
    if (preset === '4:3') return (4 / 3) / imgRatio;
    if (preset === '3:2') return (3 / 2) / imgRatio;
    return null;
  };

  const handleSelectAspect = (preset: CropAspectPreset) => {
    setAspectPreset(preset);
    if (preset === 'free') return;

    const normRatio = getTargetAspect(preset);
    if (!normRatio) return;

    // Fit centered crop inside current bounds with normalized aspect ratio
    let w = 0.86;
    let h = w / normRatio;
    if (h > 0.86) {
      h = 0.86;
      w = h * normRatio;
    }
    w = Math.min(1, Math.max(MIN_CROP_SIZE, w));
    h = Math.min(1, Math.max(MIN_CROP_SIZE, h));

    setEdit((prev) => ({
      ...prev,
      crop: {
        x: (1 - w) / 2,
        y: (1 - h) / 2,
        width: w,
        height: h,
      },
    }));
  };

  const handlePointerDown = (handle: DragHandle, e: React.PointerEvent) => {
    e.stopPropagation();
    e.preventDefault();
    const stage = stageRef.current;
    if (!stage) return;

    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    dragStateRef.current = {
      handle,
      startX: e.clientX,
      startY: e.clientY,
      startCrop: { ...edit.crop },
      stageRect: stage.getBoundingClientRect(),
    };
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    const state = dragStateRef.current;
    if (!state) return;

    const dx = (e.clientX - state.startX) / Math.max(1, state.stageRect.width);
    const dy = (e.clientY - state.startY) / Math.max(1, state.stageRect.height);
    const s = state.startCrop;
    const normRatio = getTargetAspect(aspectPreset);

    let next: CropRect = { ...s };

    if (state.handle === 'move') {
      next.x = Math.max(0, Math.min(1 - s.width, s.x + dx));
      next.y = Math.max(0, Math.min(1 - s.height, s.y + dy));
    } else {
      let left = s.x;
      let top = s.y;
      let right = s.x + s.width;
      let bottom = s.y + s.height;

      if (state.handle.includes('w')) left = Math.max(0, Math.min(right - MIN_CROP_SIZE, s.x + dx));
      if (state.handle.includes('e')) right = Math.min(1, Math.max(left + MIN_CROP_SIZE, s.x + s.width + dx));
      if (state.handle.includes('n')) top = Math.max(0, Math.min(bottom - MIN_CROP_SIZE, s.y + dy));
      if (state.handle.includes('s')) bottom = Math.min(1, Math.max(top + MIN_CROP_SIZE, s.y + s.height + dy));

      if (normRatio) {
        let w = right - left;
        let h = bottom - top;
        if (state.handle === 'n' || state.handle === 's') {
          w = h * normRatio;
          if (left + w > 1) {
            w = 1 - left;
            h = w / normRatio;
          }
        } else {
          h = w / normRatio;
          if (top + h > 1) {
            h = 1 - top;
            w = h * normRatio;
          }
        }
        right = left + Math.max(MIN_CROP_SIZE, w);
        bottom = top + Math.max(MIN_CROP_SIZE, h);
      }

      next = {
        x: left,
        y: top,
        width: Math.max(MIN_CROP_SIZE, right - left),
        height: Math.max(MIN_CROP_SIZE, bottom - top),
      };
    }

    setEdit((prev) => ({ ...prev, crop: next }));
  };

  const handlePointerUp = () => {
    dragStateRef.current = null;
  };

  const rotateBy = (delta: -90 | 90) => {
    setEdit((prev) => {
      const nextRot = (((prev.rotation + delta) % 360) + 360) % 360 as 0 | 90 | 180 | 270;
      return {
        ...prev,
        rotation: nextRot,
        crop: { ...DEFAULT_CROP },
      };
    });
  };

  const handleResetCrop = () => {
    setAspectPreset('free');
    setEdit((prev) => ({ ...prev, crop: { ...DEFAULT_CROP } }));
  };

  const handleResetAll = () => {
    setAspectPreset('free');
    setEdit({
      ...DEFAULT_EDIT_SETTINGS,
      crop: { ...DEFAULT_CROP },
    });
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await onSave(photo.id, edit);
      onClose();
    } finally {
      setIsSaving(false);
    }
  };

  const handleApplyAllFilters = async () => {
    setIsApplyingAll(true);
    try {
      await onApplyFilterToAll(edit.filter, edit.brightness, edit.contrast);
    } finally {
      setIsApplyingAll(false);
    }
  };

  const filterList: FilterPreset[] = ['original', 'document', 'grayscale', 'bw', 'vivid'];
  const displaySrc = filteredPreviewUrl || orientedPreviewUrl || photo.previewDataUrl;

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col bg-[#0E131B] text-white"
      role="dialog"
      aria-modal="true"
      aria-label={t.editorTitle}
    >
      {/* Top Bar */}
      <div className="flex items-center justify-between px-4 h-14 border-b border-white/10 shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
            aria-label={t.cancel}
          >
            <X className="w-5 h-5" />
          </button>
          <div className="min-w-0">
            <h2 className="text-sm sm:text-base font-semibold truncate">{t.editorTitle}</h2>
            <p className="text-xs text-slate-400 tabular-nums truncate">
              {t.pageLabel} {toLocalizedNumber(pageNumber, lang)} / {toLocalizedNumber(totalPhotos, lang)}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={handleResetAll}
            className="min-h-[44px] px-3 rounded-xl text-xs font-medium text-slate-300 hover:text-white hover:bg-white/10 transition-colors whitespace-nowrap"
          >
            {t.resetAll}
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={isSaving}
            className="min-h-[44px] px-4 rounded-xl text-xs sm:text-sm font-semibold bg-[#D92D20] hover:bg-[#B42318] disabled:opacity-50 text-white flex items-center gap-1.5 transition-colors whitespace-nowrap"
          >
            <Check className="w-4 h-4" />
            <span>{t.applyChanges}</span>
          </button>
        </div>
      </div>

      {/* Stage */}
      <div className="flex-1 flex items-center justify-center p-4 sm:p-6 overflow-hidden bg-[#080B10]">
        <div
          ref={stageRef}
          className="relative inline-block select-none touch-none max-w-full max-h-full"
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
        >
          <img
            src={displaySrc}
            alt={photo.name}
            draggable={false}
            className="block max-h-[52vh] sm:max-h-[58vh] max-w-full w-auto h-auto rounded-sm pointer-events-none"
          />

          {/* Interactive Crop Overlay */}
          {activeTab === 'crop' && (
            <div className="absolute inset-0">
              {/* Four dark mask strips around crop box */}
              <div
                className="absolute bg-black/60 pointer-events-none"
                style={{ top: 0, left: 0, right: 0, height: `${edit.crop.y * 100}%` }}
              />
              <div
                className="absolute bg-black/60 pointer-events-none"
                style={{
                  top: `${(edit.crop.y + edit.crop.height) * 100}%`,
                  left: 0,
                  right: 0,
                  bottom: 0,
                }}
              />
              <div
                className="absolute bg-black/60 pointer-events-none"
                style={{
                  top: `${edit.crop.y * 100}%`,
                  left: 0,
                  width: `${edit.crop.x * 100}%`,
                  height: `${edit.crop.height * 100}%`,
                }}
              />
              <div
                className="absolute bg-black/60 pointer-events-none"
                style={{
                  top: `${edit.crop.y * 100}%`,
                  left: `${(edit.crop.x + edit.crop.width) * 100}%`,
                  right: 0,
                  height: `${edit.crop.height * 100}%`,
                }}
              />

              {/* Draggable Crop Box */}
              <div
                onPointerDown={(e) => handlePointerDown('move', e)}
                className="absolute border-2 border-white cursor-move shadow-[0_0_0_1px_rgba(0,0,0,0.4)]"
                style={{
                  left: `${edit.crop.x * 100}%`,
                  top: `${edit.crop.y * 100}%`,
                  width: `${edit.crop.width * 100}%`,
                  height: `${edit.crop.height * 100}%`,
                }}
              >
                {/* Rule-of-thirds grid */}
                <div className="pointer-events-none absolute inset-0 grid grid-cols-3 grid-rows-3">
                  <div className="border-r border-b border-white/25" />
                  <div className="border-r border-b border-white/25" />
                  <div className="border-b border-white/25" />
                  <div className="border-r border-b border-white/25" />
                  <div className="border-r border-b border-white/25" />
                  <div className="border-b border-white/25" />
                  <div className="border-r border-white/25" />
                  <div className="border-r border-white/25" />
                  <div />
                </div>

                {/* Corner Handles (with generous invisible touch hitboxes) */}
                {(
                  [
                    { id: 'nw', pos: '-top-3 -left-3 cursor-nwse-resize', dot: 'top-2.5 left-2.5' },
                    { id: 'ne', pos: '-top-3 -right-3 cursor-nesw-resize', dot: 'top-2.5 right-2.5' },
                    { id: 'sw', pos: '-bottom-3 -left-3 cursor-nesw-resize', dot: 'bottom-2.5 left-2.5' },
                    { id: 'se', pos: '-bottom-3 -right-3 cursor-nwse-resize', dot: 'bottom-2.5 right-2.5' },
                  ] as const
                ).map((h) => (
                  <div
                    key={h.id}
                    onPointerDown={(e) => handlePointerDown(h.id, e)}
                    className={`absolute w-8 h-8 ${h.pos} flex items-center justify-center`}
                  >
                    <span className="w-3.5 h-3.5 bg-white border-2 border-[#D92D20] rounded-sm shadow" />
                  </div>
                ))}

                {/* Edge Handles */}
                <div
                  onPointerDown={(e) => handlePointerDown('n', e)}
                  className="absolute -top-2.5 left-6 right-6 h-5 cursor-ns-resize flex items-center justify-center"
                >
                  <span className="w-7 h-1 bg-white rounded-full shadow" />
                </div>
                <div
                  onPointerDown={(e) => handlePointerDown('s', e)}
                  className="absolute -bottom-2.5 left-6 right-6 h-5 cursor-ns-resize flex items-center justify-center"
                >
                  <span className="w-7 h-1 bg-white rounded-full shadow" />
                </div>
                <div
                  onPointerDown={(e) => handlePointerDown('w', e)}
                  className="absolute top-6 bottom-6 -left-2.5 w-5 cursor-ew-resize flex items-center justify-center"
                >
                  <span className="h-7 w-1 bg-white rounded-full shadow" />
                </div>
                <div
                  onPointerDown={(e) => handlePointerDown('e', e)}
                  className="absolute top-6 bottom-6 -right-2.5 w-5 cursor-ew-resize flex items-center justify-center"
                >
                  <span className="h-7 w-1 bg-white rounded-full shadow" />
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Bottom Controls Drawer */}
      <div className="bg-[#141B26] border-t border-white/10 px-4 pt-3 pb-4 pb-safe shrink-0">
        <div className="max-w-3xl mx-auto space-y-3">
          {/* Active Tool Options */}
          {activeTab === 'crop' && (
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 overflow-x-auto">
                {(
                  [
                    { id: 'free', label: t.aspectFree },
                    { id: 'a4', label: t.aspectA4 },
                    { id: 'square', label: t.aspectSquare },
                    { id: '4:3', label: '4:3' },
                    { id: '3:2', label: '3:2' },
                  ] as const
                ).map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleSelectAspect(item.id)}
                    className={`min-h-[40px] px-3 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                      aspectPreset === item.id
                        ? 'bg-white text-slate-900'
                        : 'bg-white/10 text-slate-300 hover:bg-white/15'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
              <button
                type="button"
                onClick={handleResetCrop}
                className="min-h-[40px] px-3 rounded-lg text-xs font-medium text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 transition-colors whitespace-nowrap"
              >
                {t.resetCrop}
              </button>
            </div>
          )}

          {activeTab === 'rotate' && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() => rotateBy(-90)}
                className="min-h-[44px] px-3 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-medium flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
              >
                <RotateCcw className="w-4 h-4" />
                <span>{t.rotateLeft}</span>
              </button>
              <button
                type="button"
                onClick={() => rotateBy(90)}
                className="min-h-[44px] px-3 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-medium flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
              >
                <RotateCw className="w-4 h-4" />
                <span>{t.rotateRight}</span>
              </button>
              <button
                type="button"
                onClick={() => setEdit((prev) => ({ ...prev, flipH: !prev.flipH }))}
                className={`min-h-[44px] px-3 rounded-xl text-xs font-medium flex items-center justify-center gap-2 transition-colors whitespace-nowrap ${
                  edit.flipH ? 'bg-white text-slate-900' : 'bg-white/10 hover:bg-white/15 text-white'
                }`}
              >
                <FlipHorizontal2 className="w-4 h-4" />
                <span>{t.flipHorizontal}</span>
              </button>
              <button
                type="button"
                onClick={() => setEdit((prev) => ({ ...prev, flipV: !prev.flipV }))}
                className={`min-h-[44px] px-3 rounded-xl text-xs font-medium flex items-center justify-center gap-2 transition-colors whitespace-nowrap ${
                  edit.flipV ? 'bg-white text-slate-900' : 'bg-white/10 hover:bg-white/15 text-white'
                }`}
              >
                <FlipVertical2 className="w-4 h-4" />
                <span>{t.flipVertical}</span>
              </button>
            </div>
          )}

          {activeTab === 'filter' && (
            <div className="space-y-3">
              <div className="flex items-center gap-2.5 overflow-x-auto pb-1">
                {filterList.map((preset) => {
                  const selected = edit.filter === preset;
                  return (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setEdit((prev) => ({ ...prev, filter: preset }))}
                      className={`shrink-0 flex flex-col items-center gap-1.5 p-1.5 rounded-xl border transition-colors ${
                        selected
                          ? 'border-[#D92D20] bg-white/10'
                          : 'border-white/10 bg-white/5 hover:bg-white/10'
                      }`}
                    >
                      <div className="w-14 h-14 rounded-lg overflow-hidden bg-slate-800">
                        {swatches[preset] ? (
                          <img src={swatches[preset]} alt="" className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full bg-slate-700" />
                        )}
                      </div>
                      <span className="text-[11px] font-medium whitespace-nowrap px-1">
                        {t.filters[preset]}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Brightness & Contrast Sliders */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <label className="flex items-center gap-3 text-xs text-slate-300">
                  <span className="w-20 shrink-0">{t.brightnessLabel}</span>
                  <input
                    type="range"
                    min={-40}
                    max={40}
                    value={edit.brightness}
                    onChange={(e) =>
                      setEdit((prev) => ({ ...prev, brightness: Number(e.target.value) }))
                    }
                    className="flex-1 accent-[#D92D20] h-2 cursor-pointer"
                  />
                  <span className="w-9 text-right font-mono-nums text-slate-200">
                    {toLocalizedNumber(edit.brightness, lang)}
                  </span>
                </label>

                <label className="flex items-center gap-3 text-xs text-slate-300">
                  <span className="w-20 shrink-0">{t.contrastLabel}</span>
                  <input
                    type="range"
                    min={-40}
                    max={40}
                    value={edit.contrast}
                    onChange={(e) =>
                      setEdit((prev) => ({ ...prev, contrast: Number(e.target.value) }))
                    }
                    className="flex-1 accent-[#D92D20] h-2 cursor-pointer"
                  />
                  <span className="w-9 text-right font-mono-nums text-slate-200">
                    {toLocalizedNumber(edit.contrast, lang)}
                  </span>
                </label>
              </div>

              {totalPhotos > 1 && (
                <div className="flex justify-end">
                  <button
                    type="button"
                    disabled={isApplyingAll}
                    onClick={handleApplyAllFilters}
                    className="min-h-[40px] px-3 rounded-lg text-xs font-medium bg-white/10 hover:bg-white/15 text-slate-100 disabled:opacity-50 transition-colors whitespace-nowrap"
                  >
                    {t.applyFilterToAll}
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Tool Selector Tabs */}
          <div className="grid grid-cols-3 gap-2 pt-1 border-t border-white/10">
            <button
              type="button"
              onClick={() => setActiveTab('crop')}
              className={`min-h-[44px] rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap ${
                activeTab === 'crop'
                  ? 'bg-white text-slate-900'
                  : 'text-slate-300 hover:bg-white/10'
              }`}
            >
              <CropIcon className="w-4 h-4" />
              <span>{t.tabCrop}</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('rotate')}
              className={`min-h-[44px] rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap ${
                activeTab === 'rotate'
                  ? 'bg-white text-slate-900'
                  : 'text-slate-300 hover:bg-white/10'
              }`}
            >
              <SlidersHorizontal className="w-4 h-4" />
              <span>{t.tabRotate}</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('filter')}
              className={`min-h-[44px] rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap ${
                activeTab === 'filter'
                  ? 'bg-white text-slate-900'
                  : 'text-slate-300 hover:bg-white/10'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span>{t.tabFilter}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
