import React, { useEffect, useState } from 'react';
import { Download, Edit3, Share2, Trash2, X } from 'lucide-react';
import { Language, SavedPdfRecord } from '../types';
import {
  TRANSLATIONS,
  formatBytes,
  formatDateTime,
  toLocalizedNumber,
} from '../i18n/translations';

interface PdfPreviewModalProps {
  record: SavedPdfRecord | null;
  lang: Language;
  onClose: () => void;
  onDownload: (record: SavedPdfRecord) => void;
  onShare: (record: SavedPdfRecord) => void;
  onRequestRename: (record: SavedPdfRecord) => void;
  onRequestDelete: (record: SavedPdfRecord) => void;
}

export const PdfPreviewModal: React.FC<PdfPreviewModalProps> = ({
  record,
  lang,
  onClose,
  onDownload,
  onShare,
  onRequestRename,
  onRequestDelete,
}) => {
  const t = TRANSLATIONS[lang];
  const [viewMode, setViewMode] = useState<'pages' | 'embed'>('pages');
  const [blobUrl, setBlobUrl] = useState<string>('');

  useEffect(() => {
    if (!record) {
      setBlobUrl('');
      return;
    }
    const url = URL.createObjectURL(record.blob);
    setBlobUrl(url);
    setViewMode('pages');
    return () => {
      URL.revokeObjectURL(url);
    };
  }, [record]);

  if (!record) return null;

  const orientationLabel = record.orientation === 'portrait' ? t.portrait : t.landscape;

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col bg-[#F4F5F7] text-slate-900"
      role="dialog"
      aria-modal="true"
      aria-label={t.previewTitle}
    >
      {/* Top Bar */}
      <div className="bg-white border-b border-slate-200 px-4 py-2.5 flex items-center justify-between gap-4 shrink-0">
        <div className="flex items-center gap-3 min-w-0">
          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors shrink-0"
            aria-label={t.close}
          >
            <X className="w-5 h-5" />
          </button>
          <div className="min-w-0">
            <h2 className="text-sm sm:text-base font-semibold text-slate-900 truncate">
              {record.name}.pdf
            </h2>
            <p className="text-xs text-slate-500 truncate tabular-nums">
              {t.pagesCount(record.pageCount)} · {record.pageSize} · {orientationLabel} ·{' '}
              {formatBytes(record.sizeBytes, lang)} · {formatDateTime(record.createdAt, lang)}
            </p>
          </div>
        </div>

        {/* View mode toggle for desktop users wanting native browser embed */}
        <div className="hidden sm:flex items-center gap-1 p-1 bg-slate-100 rounded-xl shrink-0">
          <button
            type="button"
            onClick={() => setViewMode('pages')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
              viewMode === 'pages'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {t.pageImagesToggle}
          </button>
          <button
            type="button"
            onClick={() => setViewMode('embed')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
              viewMode === 'embed'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {t.nativeViewerToggle}
          </button>
        </div>
      </div>

      {/* Document Viewport */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-8">
        {viewMode === 'pages' ? (
          <div className="max-w-3xl mx-auto space-y-6">
            {record.pagePreviews && record.pagePreviews.length > 0 ? (
              record.pagePreviews.map((imgUrl, index) => (
                <div
                  key={index}
                  className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden"
                >
                  <div className="px-4 py-2 border-b border-slate-100 flex items-center justify-between text-xs text-slate-500 tabular-nums">
                    <span>{t.pageOfTotal(index + 1, record.pageCount)}</span>
                    <span>
                      {record.pageSize} · {orientationLabel}
                    </span>
                  </div>
                  <div className="p-3 sm:p-5 bg-slate-50 flex justify-center">
                    <img
                      src={imgUrl}
                      alt={`${record.name} ${toLocalizedNumber(index + 1, lang)}`}
                      className="max-w-full h-auto shadow-md bg-white border border-slate-200"
                    />
                  </div>
                </div>
              ))
            ) : (
              <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center">
                <img
                  src={record.thumbnailDataUrl}
                  alt={record.name}
                  className="max-w-md w-full mx-auto rounded border border-slate-200 shadow-sm"
                />
              </div>
            )}
          </div>
        ) : (
          <div className="max-w-5xl mx-auto h-full min-h-[70vh] bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
            {blobUrl && (
              <iframe
                src={blobUrl}
                title={record.name}
                className="w-full h-full min-h-[70vh] border-0"
              />
            )}
          </div>
        )}
      </div>

      {/* Bottom Action Bar */}
      <div className="bg-white border-t border-slate-200 px-4 py-3 pb-safe shrink-0">
        <div className="max-w-3xl mx-auto grid grid-cols-4 gap-2 sm:flex sm:items-center sm:justify-end sm:gap-3">
          <button
            type="button"
            onClick={() => onRequestRename(record)}
            className="min-h-[44px] px-3 sm:px-4 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs sm:text-sm font-medium flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
          >
            <Edit3 className="w-4 h-4 shrink-0" />
            <span className="truncate">{t.renamePdf}</span>
          </button>

          <button
            type="button"
            onClick={() => onRequestDelete(record)}
            className="min-h-[44px] px-3 sm:px-4 rounded-xl border border-red-200 bg-white hover:bg-red-50 text-red-700 text-xs sm:text-sm font-medium flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
          >
            <Trash2 className="w-4 h-4 shrink-0" />
            <span className="truncate">{t.deletePdf}</span>
          </button>

          <button
            type="button"
            onClick={() => onShare(record)}
            className="min-h-[44px] px-3 sm:px-4 rounded-xl border border-slate-200 bg-slate-900 hover:bg-slate-800 text-white text-xs sm:text-sm font-medium flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
          >
            <Share2 className="w-4 h-4 shrink-0" />
            <span className="truncate">{t.sharePdf}</span>
          </button>

          <button
            type="button"
            onClick={() => onDownload(record)}
            className="min-h-[44px] px-3 sm:px-4 rounded-xl bg-[#D92D20] hover:bg-[#B42318] text-white text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
          >
            <Download className="w-4 h-4 shrink-0" />
            <span className="truncate">{t.downloadPdf}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
