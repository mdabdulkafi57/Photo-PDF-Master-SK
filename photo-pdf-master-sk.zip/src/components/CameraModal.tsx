import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Camera, Check, RefreshCw, RotateCcw, Upload, X } from 'lucide-react';
import { Language } from '../types';
import { TRANSLATIONS, toLocalizedNumber } from '../i18n/translations';
import { readFileAsDataUrl } from '../utils/imageProcessing';

interface CameraModalProps {
  isOpen: boolean;
  lang: Language;
  onClose: () => void;
  onConfirmPhotos: (dataUrls: string[]) => void;
}

export const CameraModal: React.FC<CameraModalProps> = ({
  isOpen,
  lang,
  onClose,
  onConfirmPhotos,
}) => {
  const t = TRANSLATIONS[lang];
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const fallbackInputRef = useRef<HTMLInputElement | null>(null);

  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [cameraState, setCameraState] = useState<'loading' | 'ready' | 'denied' | 'unavailable'>('loading');
  const [capturedPhotos, setCapturedPhotos] = useState<string[]>([]);
  const [flashEffect, setFlashEffect] = useState(false);

  const stopStream = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  }, []);

  const startCamera = useCallback(
    async (mode: 'environment' | 'user') => {
      stopStream();
      setCameraState('loading');

      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setCameraState('unavailable');
        return;
      }

      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: { ideal: mode },
            width: { ideal: 1920 },
            height: { ideal: 1080 },
          },
          audio: false,
        });
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
        }
        setCameraState('ready');
      } catch (err) {
        if (err instanceof DOMException && (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError')) {
          setCameraState('denied');
        } else {
          setCameraState('unavailable');
        }
      }
    },
    [stopStream]
  );

  useEffect(() => {
    if (isOpen) {
      setCapturedPhotos([]);
      startCamera(facingMode);
    } else {
      stopStream();
    }
    return () => {
      stopStream();
    };
  }, [isOpen, facingMode, startCamera, stopStream]);

  if (!isOpen) return null;

  const handleCapture = () => {
    const video = videoRef.current;
    if (!video || cameraState !== 'ready') return;

    const w = video.videoWidth || 1280;
    const h = video.videoHeight || 720;
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    if (facingMode === 'user') {
      ctx.translate(w, 0);
      ctx.scale(-1, 1);
    }
    ctx.drawImage(video, 0, 0, w, h);

    const dataUrl = canvas.toDataURL('image/jpeg', 0.92);
    setCapturedPhotos((prev) => [...prev, dataUrl]);
    setFlashEffect(true);
    setTimeout(() => setFlashEffect(false), 160);
  };

  const handleFallbackFiles = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const urls: string[] = [];
    for (let i = 0; i < files.length; i++) {
      try {
        const url = await readFileAsDataUrl(files[i]);
        urls.push(url);
      } catch {
        // ignore unreadable file
      }
    }
    if (urls.length > 0) {
      setCapturedPhotos((prev) => [...prev, ...urls]);
    }
    e.target.value = '';
  };

  const handleSwitchCamera = () => {
    setFacingMode((prev) => (prev === 'environment' ? 'user' : 'environment'));
  };

  const handleDiscardLast = () => {
    setCapturedPhotos((prev) => prev.slice(0, -1));
  };

  const handleConfirm = () => {
    if (capturedPhotos.length === 0) return;
    stopStream();
    onConfirmPhotos(capturedPhotos);
  };

  const handleClose = () => {
    stopStream();
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col bg-[#0B0F17] text-white"
      role="dialog"
      aria-modal="true"
      aria-label={t.cameraTitle}
    >
      {/* Top Bar */}
      <div className="flex items-center justify-between px-4 h-14 border-b border-white/10 shrink-0">
        <div className="flex items-center gap-3 min-w-0">
          <button
            type="button"
            onClick={handleClose}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
            aria-label={t.close}
          >
            <X className="w-5 h-5" />
          </button>
          <h2 className="text-base font-semibold truncate">{t.cameraTitle}</h2>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {capturedPhotos.length > 0 && (
            <span className="text-xs text-slate-300 tabular-nums px-2">
              {t.capturedCount(capturedPhotos.length)}
            </span>
          )}
          <button
            type="button"
            onClick={handleSwitchCamera}
            disabled={cameraState !== 'ready'}
            className="min-h-[44px] px-3 flex items-center gap-2 rounded-xl text-xs font-medium bg-white/10 hover:bg-white/15 disabled:opacity-40 transition-colors whitespace-nowrap"
          >
            <RefreshCw className="w-4 h-4" />
            <span className="hidden sm:inline">{t.switchCamera}</span>
          </button>
        </div>
      </div>

      {/* Viewfinder Stage */}
      <div className="relative flex-1 flex items-center justify-center overflow-hidden bg-black">
        <video
          ref={videoRef}
          playsInline
          muted
          className={`w-full h-full object-contain transition-opacity duration-200 ${
            cameraState === 'ready' ? 'opacity-100' : 'opacity-0'
          } ${facingMode === 'user' ? '-scale-x-100' : ''}`}
        />

        {/* Document Framing Corner Guides */}
        {cameraState === 'ready' && (
          <div className="pointer-events-none absolute inset-6 sm:inset-12 max-w-2xl mx-auto my-auto aspect-[3/4] max-h-[70vh] border border-white/15 rounded-lg">
            <span className="absolute -top-0.5 -left-0.5 w-6 h-6 border-t-2 border-l-2 border-white rounded-tl-md" />
            <span className="absolute -top-0.5 -right-0.5 w-6 h-6 border-t-2 border-r-2 border-white rounded-tr-md" />
            <span className="absolute -bottom-0.5 -left-0.5 w-6 h-6 border-b-2 border-l-2 border-white rounded-bl-md" />
            <span className="absolute -bottom-0.5 -right-0.5 w-6 h-6 border-b-2 border-r-2 border-white rounded-br-md" />
            <div className="absolute bottom-3 left-0 right-0 text-center px-4">
              <span className="inline-block px-3 py-1 rounded-lg bg-black/60 text-xs text-white/90">
                {t.cameraGuideHint}
              </span>
            </div>
          </div>
        )}

        {/* Shutter Flash Overlay */}
        {flashEffect && (
          <div className="pointer-events-none absolute inset-0 bg-white/75 transition-opacity" />
        )}

        {/* Loading / Fallback States */}
        {cameraState === 'loading' && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 text-slate-300">
            <div className="w-8 h-8 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          </div>
        )}

        {(cameraState === 'denied' || cameraState === 'unavailable') && (
          <div className="absolute inset-0 flex items-center justify-center p-6">
            <div className="max-w-md w-full bg-[#151C28] border border-white/10 rounded-2xl p-6 text-center space-y-4">
              <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center mx-auto text-white">
                <Camera className="w-6 h-6" />
              </div>
              <p className="text-sm text-slate-200 leading-relaxed">
                {cameraState === 'denied' ? t.cameraPermissionDenied : t.cameraUnavailable}
              </p>
              <input
                ref={fallbackInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                multiple
                onChange={handleFallbackFiles}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fallbackInputRef.current?.click()}
                className="w-full min-h-[44px] px-4 py-2.5 rounded-xl bg-[#D92D20] hover:bg-[#B42318] text-white text-sm font-semibold flex items-center justify-center gap-2 transition-colors"
              >
                <Upload className="w-4 h-4" />
                <span>{t.cameraFallbackAction}</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Captured Strip + Bottom Controls */}
      <div className="bg-[#111722] border-t border-white/10 px-4 pt-3 pb-5 pb-safe space-y-3 shrink-0">
        {capturedPhotos.length > 0 && (
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {capturedPhotos.map((url, idx) => (
              <div
                key={`${idx}-${url.slice(-16)}`}
                className="relative w-12 h-16 rounded-lg overflow-hidden border border-white/20 shrink-0 bg-black"
              >
                <img src={url} alt="" className="w-full h-full object-cover" />
                <span className="absolute bottom-0.5 right-1 text-[10px] font-mono-nums bg-black/70 text-white px-1 rounded">
                  {toLocalizedNumber(idx + 1, lang)}
                </span>
              </div>
            ))}
          </div>
        )}

        <div className="max-w-lg mx-auto flex items-center justify-between gap-4">
          <button
            type="button"
            onClick={handleDiscardLast}
            disabled={capturedPhotos.length === 0}
            className="min-h-[44px] min-w-[84px] px-3 py-2 rounded-xl text-xs font-medium text-slate-200 bg-white/10 hover:bg-white/15 disabled:opacity-35 flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap"
          >
            <RotateCcw className="w-4 h-4" />
            <span>{t.retakeLast}</span>
          </button>

          <button
            type="button"
            onClick={handleCapture}
            disabled={cameraState !== 'ready'}
            aria-label={t.capturePhoto}
            className="w-16 h-16 rounded-full border-4 border-white flex items-center justify-center p-1 disabled:opacity-35 active:scale-95 transition-transform shrink-0"
          >
            <span className="w-full h-full rounded-full bg-white hover:bg-slate-100 block" />
          </button>

          <button
            type="button"
            onClick={handleConfirm}
            disabled={capturedPhotos.length === 0}
            className="min-h-[44px] min-w-[100px] px-4 py-2 rounded-xl text-xs font-semibold text-white bg-[#D92D20] hover:bg-[#B42318] disabled:opacity-35 flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap"
          >
            <Check className="w-4 h-4" />
            <span>{t.addCapturedPhotos(capturedPhotos.length)}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
